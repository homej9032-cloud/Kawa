/* JARVIS v3 · glitch-free voice, never-silent voice (device fallback), wake word, native offline STT glue, fresh screenshots, more phone tools */
(()=>{
const $=i=>document.getElementById(i),nat=!!(window.Phone&&Phone.voiceReady),sleep=ms=>new Promise(r=>setTimeout(r,ms)),setLive=v=>$('bMic')&&$('bMic').classList.toggle('live',!!v);
let wakeOn=false,hold=false,lastH=null,wr=null,qUntil=0;
/* ---- 1. end-of-paragraph glitch: trim leading/trailing junk, drop a short stray burst after a pause, fade in/out, pad silence ---- */
function clean(b){try{const r=b.sampleRate,x=b.getChannelData(0),n=x.length,T=.012,G=Math.floor(r*.2),W=Math.floor(r*.22);
 let s=0;while(s<n&&Math.abs(x[s])<T)s++;s=Math.max(0,s-Math.floor(r*.012));let e=n;while(e>s&&Math.abs(x[e-1])<T)e--;
 let run=0;for(let i=e-1;i>s&&e-i<r*.7;i--){if(Math.abs(x[i])<T){if(++run>=G){if(e-(i+run)<W){e=i;while(e>s&&Math.abs(x[e-1])<T)e--}break}}else run=0}
 const len=e-s,o=ac.createBuffer(1,len+Math.floor(r*.06),r),y=o.getChannelData(0);y.set(x.subarray(s,e));
 const fi=Math.floor(r*.006),fo=Math.min(len,Math.floor(r*.035));for(let i=0;i<fi;i++)y[i]*=i/fi;for(let i=0;i<fo;i++)y[len-1-i]*=i/fo;return o}catch(e){return b}}
const _o=window.ttsOne;window.ttsOne=async(m,t,a)=>clean(await _o(m,t,a));
/* ---- 2. voice never goes silent: Gemini quota/offline -> device voice (native TextToSpeech in the app, speechSynthesis in browser) ---- */
const _t=window.tts,_p=window.playBuf,_s=window.stopSay;
window.tts=async(text,my)=>{try{return await _t(text,my)}catch(e){if(my!=gid)return null;throw e}};
function sysPlay(text,my){return new Promise(res=>{let d=0;const fin=()=>{if(!d){d=1;res()}};sp=true;ana=null;
 if(window.Phone&&Phone.speak){window.onSpeakEnd=fin;Phone.speak(text,C.lang||'en-IN')}else{const u=new SpeechSynthesisUtterance(text);u.lang=C.lang||'en-US';u.rate=1.05;u.onend=u.onerror=fin;speechSynthesis.speak(u)}
 const iv=setInterval(()=>{if(d)return clearInterval(iv);if(my!=gid){clearInterval(iv);try{speechSynthesis.cancel()}catch(e){}try{Phone.speakStop&&Phone.speakStop()}catch(e){}fin()}},120)})}
window.playBuf=(b,t,my)=>b&&b.sys?sysPlay(b.text,my):_p(b,t,my);
window.stopSay=function(){try{speechSynthesis.cancel()}catch(e){}try{window.Phone&&Phone.speakStop&&Phone.speakStop()}catch(e){}return _s.apply(this,arguments)};
/* ---- 3. Screen Share button -> fast voice Talk button; screenshots are fresh every time (no sharing, works over any app) ---- */
const tb=$('bScr');if(tb){tb.innerHTML='<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 10v4M8 6v12M12 3v18M16 7v10M20 10v4"/></svg>';tb.title='Talk';tb.onclick=()=>window.jxGo&&jxGo('speak')}
const thumb=b=>{const d=document.createElement('div');d.className='m j gc';d.innerHTML='<img alt="" src="data:image/jpeg;base64,'+b+'" style="width:100%;max-width:220px;border-radius:14px;display:block">';document.body.classList.remove('empty');$('msgs').append(d);$('msgs').scrollTop=1e9};
JT.look_screen={d:'Take a FRESH screenshot of whatever is on the phone screen right now (any app) and answer a question about it. Nothing needs to be shared or turned on. To see another app, phone_open it first, then call this. Call it again any time you need a new look.',p:{'?question':'What to look for'},
 f:async a=>{if(!(window.Phone&&Phone.shot))throw Error('Seeing other apps needs the JARVIS Android app. The web version cannot see outside the browser.');if(C.prov!='gemini')throw Error('Vision needs the Gemini provider');
  let f='';for(let i=0;i<3&&!f;i++){f=Phone.shot();if(!f)await sleep(600)}if(!f)throw Error('Screenshot failed. Turn JARVIS phone control on in Accessibility.');thumb(f);
  return{answer:txt(await gen([{role:'user',parts:[{inline_data:{mime_type:'image/jpeg',data:f}},{text:a.question||'Describe what is on this screen.'}]}]))}}};
/* ---- 4. more phone control ---- */
if(window.Phone){const R=/subscribe|send|post|comment|buy|pay|delete|remove|submit|order|purchase|confirm|share|reply|publish/i,run=s=>{if(/^ERROR/.test(s))throw Error(s.slice(7));return s},
 ask=(n,a)=>{if((!C.auto||/pay|transfer|send money|purchase|buy now|place order|delete (my )?account|factory reset|erase all/i.test(JSON.stringify(a)))&&!confirm('JARVIS wants to '+n+': '+JSON.stringify(a).slice(0,200)))throw Error('User declined')},yes=v=>/^(true|yes|on|1)/i.test(String(v)),scr=()=>String(Phone.screen()).toLowerCase();
 Object.assign(JT,{
 phone_contacts:{d:'PHONE CONTROL: search the phone contacts by name. Returns names and numbers.',p:{query:'Name or part of a name'},f:async a=>run(Phone.contacts(a.query))},
 phone_call:{d:'PHONE CONTROL: place a call right now to a contact name or a phone number.',p:{who:'Contact name or number'},f:async a=>{ask('call',a);return run(Phone.call(a.who))}},
 phone_location:{d:'PHONE CONTROL: current GPS location with street address.',f:async()=>run(Phone.location())},
 phone_media:{d:'PHONE CONTROL: control music/video in any app. action = play, pause, next, previous or stop.',p:{action:'play, pause, next, previous or stop'},f:async a=>run(Phone.media(a.action))},
 phone_notifications:{d:'PHONE CONTROL: read the notifications on the phone right now (needs notification access once).',f:async()=>run(Phone.notifications())},
 phone_toggle:{d:'PHONE CONTROL: flip a quick-settings switch by name: Wi-Fi, Bluetooth, Flashlight, Airplane mode, Do not disturb, Auto-rotate, Hotspot, Mobile data, Battery Saver, Location. Verify afterwards with phone_screen.',p:{name:'Tile name'},
  f:async a=>{run(Phone.system('quick'));await sleep(1100);let r;try{r=run(Phone.tap(a.name))}catch(e){Phone.back();throw e}await sleep(450);Phone.back();return r+' (quick settings closed)'}},
 phone_find:{d:'PHONE CONTROL: scroll the current screen until a text is visible, optionally tap it.',p:{text:'Text to find','?tap':'true to tap it'},
  f:async a=>{const t=yes(a.tap);if(t&&R.test(a.text))ask('tap',a);for(let i=0;i<9;i++){if(scr().includes(String(a.text).toLowerCase()))return t?run(Phone.tap(a.text)):'found "'+a.text+'" on screen';Phone.scroll('down');await sleep(750)}throw Error('"'+a.text+'" not found after scrolling')}},
 phone_wait_for:{d:'PHONE CONTROL: wait until a text appears on screen (max 20 s). Use after opening an app or page.',p:{text:'Text to wait for','?seconds':'1-20'},
  f:async a=>{const end=Date.now()+Math.min(20,Math.max(1,+a.seconds||8))*1000;while(Date.now()<end){if(scr().includes(String(a.text).toLowerCase()))return'"'+a.text+'" is on screen';await sleep(500)}throw Error('"'+a.text+'" did not appear')}},
 phone_keys:{d:'PHONE CONTROL: editing keys for the focused text field: enter, select_all, copy, cut, paste, clear.',p:{action:'enter, select_all, copy, cut, paste or clear'},f:async a=>run(Phone.keys(a.action))},
 phone_whatsapp:{d:'PHONE CONTROL: send a WhatsApp message to a number (with country code): opens the chat with the text filled in and taps Send.',p:{number:'Number with country code',text:'Message'},
  f:async a=>{ask('send WhatsApp',a);const d=String(a.number).replace(/\D/g,'');if(d.length<8)throw Error('Need the full number with country code');run(Phone.url('https://wa.me/'+d+'?text='+encodeURIComponent(a.text)));await sleep(3600);return run(Phone.tap('Send'))}},
 phone_screenshot:{d:'PHONE CONTROL: save a screenshot of the phone screen to the gallery. (To LOOK at the screen use look_screen.)',f:async()=>run(Phone.system('screenshot'))}})}
/* ---- 5. wake word ("Hey Jarvis" / "Wake up Jarvis") + offline speech ---- */
const chime=()=>{try{ac=ac||new(window.AudioContext||webkitAudioContext)();[660,990].forEach((q,i)=>{const o=ac.createOscillator(),g=ac.createGain(),t=ac.currentTime+i*.11;o.frequency.value=q;g.gain.setValueAtTime(.08,t);g.gain.exponentialRampToValueAtTime(.0001,t+.12);o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+.13)})}catch(e){}};
function onWake(){chime();window.jxGo&&jxGo('speak');setTimeout(()=>{if(!listening&&!busy)listen()},350)}
const WR=window.SpeechRecognition||window.webkitSpeechRecognition,isWake=t=>/\b(jarvis|jarvas|jarves|jervis|garvis)\b/.test(t)||(/\b(hey|wake up|ok|okay)\b/.test(t)&&/\b(travis|davis|service)\b/.test(t));
function webWake(){const want=wakeOn&&!nat&&WR&&!hold;
 if(want&&!wr){const r=wr=new WR;r.continuous=true;r.interimResults=true;r.lang=C.lang||'en-US';try{r.processLocally=true}catch(e){}
  r.onresult=e=>{const t=[...e.results].slice(e.resultIndex).map(x=>x[0].transcript).join(' ').toLowerCase();if(isWake(t)){r.onend=null;wr=null;try{r.stop()}catch(e){}onWake()}};
  r.onend=()=>{if(wr===r)wr=null;wakeOn&&setTimeout(webWake,600)};r.onerror=()=>{};try{r.start()}catch(e){wr=null}}
 else if(!want&&wr){const r=wr;wr=null;r.onend=null;try{r.abort()}catch(e){}}}
const _l=window.listen2;
if(nat){window.onVoice=(t,x)=>{if(t=='partial'){window.jxI=x;$('q').value=x}else if(t=='start'){listening=true;setLive(1)}
  else if(t=='final'){listening=false;setLive(0);window.jxI='';$('q').value='';x.trim()?turn(x.trim()):after()}else if(t=='wake')onWake();else if(t=='error')pp(x);else if(t=='ready')pp('Offline voice ready')};
 window.listen2=async()=>{stopSay();if(listening){Phone.listenStop();listening=false;setLive(0);return}const r=Phone.listenStart();if(/^ERROR/.test(r))pp(r.slice(7))}}
else window.listen2=async function(){if(wr){const r=wr;wr=null;r.onend=null;try{r.abort()}catch(e){}await sleep(250)}return _l.apply(this,arguments)};
function setWake(on,quiet){wakeOn=on;try{localStorage.jxw=on?'1':'0'}catch(e){}const b=$('jxw');b&&(b.textContent='WAKE: '+(on?'ON':'OFF'));!quiet&&pp(on?'Wake word on. Say "Hey Jarvis"':'Wake word off');nat?Phone.wakeEnable(on):webWake()}
const ch=document.querySelector('#jxs .chs');if(ch){const b=document.createElement('button');b.id='jxw';b.onclick=()=>setWake(!wakeOn);ch.append(b)}
let sv0='';try{sv0=localStorage.jxw||''}catch(e){}
if(nat)Phone.voiceInit();setWake(sv0=='1'||(nat&&sv0!='0'),true);
setInterval(()=>{hold=!!(sp||busy||listening);if(nat){if(hold!==lastH){lastH=hold;Phone.wakeHold(hold)}}else webWake()},400);
/* ---- Speak screen: more of the blue HUD (left gauges, right module column) ---- */
{const css=document.createElement('style');css.textContent='.rc{position:absolute;right:10px;top:calc(max(10px,env(safe-area-inset-top)) + 100px);display:grid;gap:10px}.rc b{width:34px;height:34px;border:1px solid rgba(127,240,255,.6);border-radius:50%;display:grid;place-items:center;font-size:15px;font-weight:400;color:#bff;background:rgba(8,40,60,.55)}.rc b:nth-child(2),.rc b:nth-child(3){border-radius:9px}';document.head.append(css);
 $('jxs').insertAdjacentHTML('beforeend','<div class="lb" style="top:calc(max(10px,env(safe-area-inset-top)) + 100px)"><div>BATTERY<i id="sb1"></i></div><div>MEMORY<i id="sb2"></i></div><div>NETWORK<i id="sb3"></i></div></div><div class="rc"><b>◎</b><b>⬡</b><b>⬢</b><b>◍</b><b>◔</b></div>');
 setInterval(()=>[1,2,3].forEach(i=>$('sb'+i).style.setProperty('--w',$('jb'+i).style.getPropertyValue('--w'))),1000)}
})();
