const C='jarvis-v12';
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(C).then(c=>c.addAll(['./','index.html','manifest.json','logo.svg','icon-192.png','icon-512.png','icon-maskable-512.png','apple-touch-icon.png','jx.js','jx2.js','jx3.js','jx4.js','jx5.js','jx6.js','jx7.js','jx8.js','jx9.js','jx10.js','jx11.js','jx12.js','body.js','fig_body.webp','fig_jaw.webp','fig_eyes.webp'])))});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(n=>n!=C).map(n=>caches.delete(n)))).then(()=>self.clients.claim())));
/* network-first, but fall back to cache after 2.5s so a slow connection never freezes launch */
self.addEventListener('fetch',e=>{if(new URL(e.request.url).hostname=='cdn.jsdelivr.net'&&e.request.method=='GET'){e.respondWith(caches.open(C).then(c=>c.match(e.request).then(r=>r||fetch(e.request).then(n=>{c.put(e.request,n.clone());return n}))));return}
if(e.request.method!='GET'||new URL(e.request.url).origin!=location.origin)return;
e.respondWith(new Promise(res=>{const t=setTimeout(()=>caches.match(e.request).then(r=>r&&res(r)),2500);
fetch(e.request).then(r=>{clearTimeout(t);const k=r.clone();caches.open(C).then(c=>c.put(e.request,k));res(r)}).catch(()=>{clearTimeout(t);caches.match(e.request).then(r=>res(r||Response.error()))})}))});
