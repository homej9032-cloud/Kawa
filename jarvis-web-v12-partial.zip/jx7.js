/* JARVIS v6 · smooth mode: sprite figure (no 3D), lite perf, sound effects, reliable listening, fast-fail requests */
(()=>{
const $=i=>document.getElementById(i),el=(t,c,h)=>{const e=document.createElement(t);c&&(e.className=c);h!=null&&(e.innerHTML=h);return e},AC=window.AudioContext||window.webkitAudioContext,nat=!!(window.Phone&&Phone.voiceReady);
const LS=(k,v)=>{try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){return null}};
/* ---------- remove every 3D entry point ---------- */
['bIron','jxsol','jx3'].forEach(i=>{const e=$(i);e&&e.remove()});
/* ---------- lite mode (old phones): no blur filters, no heavy shadows, fewer particles ---------- */
const st=el('style');st.textContent=`
.hh{display:flex;align-items:center;justify-content:center}
.fig{position:relative;flex:none}.fig img{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;user-select:none}
.fig .fj{will-change:transform}.fig .fe{will-change:opacity}.fig .cr{transform:translate(-50%,-50%);aspect-ratio:1;pointer-events:auto}
.fig .cr.lis .h{background:radial-gradient(circle,rgba(210,255,230,.95),rgba(53,255,181,.4) 30%,transparent 62%)}
.fig .fs{position:absolute;left:8%;right:8%;top:0;height:14%;background:linear-gradient(180deg,transparent,rgba(79,227,255,.13),transparent);animation:jxsw 5.5s linear infinite;pointer-events:none}
@keyframes jxsw{from{transform:translateY(-20%)}to{transform:translateY(700%)}}
body.lite *{backdrop-filter:none!important;-webkit-backdrop-filter:none!important;text-shadow:none!important}
body.lite #top,body.lite #dock{background:rgba(8,18,30,.96)!important;box-shadow:none!important}
body.lite .tl button,body.lite .pill,body.lite .sbar,body.lite #jxt,body.lite .gl,body.lite #jxcard,body.lite .chs button{box-shadow:none!important}
body.lite .ar .r1,body.lite .ar .r2,body.lite .m{animation:none!important}body.lite .fig .fs{display:none}
body.lite *{transition-duration:.1s!important}
#jx7t{position:fixed;left:50%;top:max(14px,env(safe-area-inset-top));transform:translateX(-50%);z-index:60;padding:9px 16px;border-radius:14px;background:rgba(6,20,34,.95);border:1px solid rgba(79,227,255,.5);color:#dff6ff;font:700 12px Manrope,system-ui,sans-serif;display:none;max-width:88vw}`;
document.head.append(st);
const lowEnd=(navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=6);
const setLite=on=>{document.body.classList.toggle('lite',!!on);window.JG&&JG.setLod&&JG.setLod(on?.42:1)};
const pref=LS('jxlite');setLite(pref==null?lowEnd:pref=='1');
if(pref==null){let n=0,t0=0;(function f(t){if(!t0)t0=t;if(++n<90)return requestAnimationFrame(f);if((t-t0)/n>32)setLite(true)})(performance.now())}
/* ---------- figure: pre-rendered front-only line art, animated with transforms only ---------- */
const RX=.4917,RY=.6286,figs=[];
for(const id of['jxhh','jxsh']){const h=$(id);if(!h)continue;const cr=h.querySelector('.cr'),f=el('div','fig','<img class="fb" src="fig_body.webp" alt=""><img class="fj" src="fig_jaw.webp" alt=""><img class="fe" src="fig_eyes.webp" alt=""><span class="fs"></span>');
 if(cr){cr.style.cssText='left:'+RX*100+'%;top:'+RY*100+'%;width:17%';f.append(cr)}h.prepend(f);const o={f,j:f.querySelector('.fj'),e:f.querySelector('.fe'),cr,s:300};figs.push(o);
 const fit=()=>{const w=h.clientWidth,hh=h.clientHeight;if(!w||!hh)return;const s=Math.round(Math.min(w*1.06,hh*1.04));o.s=s;f.style.width=f.style.height=s+'px'};new ResizeObserver(fit).observe(h);fit()}
const glow=(c,o,s)=>{const a=c&&c.firstChild;a&&(a.style.setProperty('--o',o),a.style.setProperty('--s',s))};
setInterval(()=>{const p=document.body.dataset.p;if(document.hidden||(p!='home'&&p!='speak'))return;const L=window.jxLevel?jxLevel():0,t=performance.now()/1000,stt=typeof cur=='function'?cur():'idle',spk=stt=='speaking',jaw=spk?Math.min(1,.2+L*2.2):0,bl=Math.pow(Math.max(0,Math.sin(t*1.3)),60);
 for(const o of figs){if(!o.f.offsetParent)continue;o.j.style.transform='translateY('+(jaw*o.s*.014).toFixed(1)+'px)';o.e.style.opacity=(.1+.9*(1-bl)*(stt=='listening'?1:.78+.12*Math.sin(t*2.2))).toFixed(2);
  if(o.cr){glow(o.cr,Math.min(1,.5+L*.8+.1*Math.sin(t*2.2)).toFixed(2),(1+L*.4).toFixed(2));o.cr.classList.toggle('lis',stt=='listening')}}},50);
/* ---------- sound effects ---------- */
const sfxOn=()=>LS('jxsfx')!='0';
function tone(f,d,v,type,f2,at){try{const c=ac=ac||new AC();c.state=='suspended'&&c.resume();const o=c.createOscillator(),g=c.createGain(),n=c.currentTime+(at||0);o.type=type||'sine';o.frequency.setValueAtTime(f,n);f2&&o.frequency.exponentialRampToValueAtTime(f2,n+d);g.gain.setValueAtTime(v,n);g.gain.exponentialRampToValueAtTime(.0001,n+d);o.connect(g);g.connect(c.destination);o.start(n);o.stop(n+d+.03)}catch(e){}}
const SFX={tap:()=>tone(1100,.05,.05,'sine',1500),on:()=>{tone(620,.07,.06,'sine',900);tone(900,.09,.06,'sine',1300,.07)},listen:()=>{tone(700,.08,.07);tone(1050,.1,.07,'sine',0,.08)},stop:()=>{tone(1050,.07,.05);tone(700,.1,.05,'sine',0,.07)},send:()=>tone(520,.12,.06,'triangle',900),done:()=>tone(1250,.09,.04,'sine',1500),err:()=>tone(180,.2,.06,'square',120)};
window.sfx=k=>{if(sfxOn()&&SFX[k])SFX[k]()};
document.addEventListener('pointerdown',e=>{const b=e.target.closest&&e.target.closest('button,[role=button],.tl button,.ox,.rcol2 button,.cr');if(b){sfx('tap');LS('jxhap')!='0'&&navigator.vibrate&&navigator.vibrate(7)}},true);
let pl=false,pb=false;setInterval(()=>{if(typeof listening=='undefined')return;if(listening!==pl){pl=listening;sfx(pl?'listen':'stop')}if(busy!==pb){pb=busy;sfx(pb?'send':'done')}},150);
/* ---------- tiny toast ---------- */
const tt=el('div');tt.id='jx7t';document.body.append(tt);let tto=0;const note=window.jx7note=m=>{if(/unreachable|didn't catch|too long|reconnect|speech service/i.test(m)){(window.jxErrLog=window.jxErrLog||[]).push({t:Date.now(),m});return}tt.textContent=m;tt.style.display='block';clearTimeout(tto);tto=setTimeout(()=>tt.style.display='none',3200)};
/* ---------- listening that actually works: on-device -> online Chrome recognizer -> (offline fallback from jx.js) ---------- */
const SR=window.SpeechRecognition||window.webkitSpeechRecognition,setLive=v=>$('bMic')&&$('bMic').classList.toggle('live',!!v);
if(!nat&&SR){const old=window.listen2;let cur0=null,failLocal=0,lastNo=0;
 const startSR=local=>{const r=new SR;cur0=r;rec=r;let fin='',err='',lastSp=Date.now();const t0=Date.now(),iv=setInterval(()=>{const hasT=!!(window.jxI||fin);if(hasT&&Date.now()-lastSp>(window.JX_SIL||1800)){try{r.stop()}catch(e){}}else if(!hasT&&Date.now()-t0>9000){try{r.stop()}catch(e){}}},250);r.lang=local==2?'en-US':(C.lang||'en-US');r.continuous=true;r.interimResults=true;r.maxAlternatives=1;if(local){try{r.processLocally=true}catch(e){}}
  r.onstart=()=>{listening=true;setLive(1)};
  r.onresult=e=>{lastSp=Date.now();let s='';for(const x of e.results){s+=x[0].transcript;if(x.isFinal)fin=s}window.jxI=s;$('q')&&($('q').value=s)};
  r.onerror=e=>{err=e.error};
  r.onend=()=>{clearInterval(iv);listening=false;setLive(0);const qv=($('q')&&$('q').value)||'';window.jxI='';const t=(qv.length>=fin.length?qv:fin).trim();$('q')&&($('q').value='');cur0=null;
   if(err=='not-allowed'||err=='service-not-allowed'){if(local){failLocal=1;return setTimeout(()=>startSR(0),120)}sfx('err');return note('Microphone is blocked. Allow it in the site settings.')}
   if(err=='language-not-supported'&&local){failLocal=1;return startSR(0)}
   if(err=='network'){sfx('err');return note('Speech service unreachable. Check your internet.')}
   if(t)return turn(t);if(Date.now()-lastNo>8000){lastNo=Date.now();note("I didn't catch that, boss.")}};
  try{r.start()}catch(e){cur0=null;note('Could not start the microphone')}};
 window.listen2=async function(){stopSay();if(listening&&cur0){try{cur0.stop()}catch(e){}return}
  if(!isSecureContext)return note('Voice needs a secure (https) page');let local=0;const lang=C.lang||'en-US';
  if(!failLocal&&'processLocally' in SR.prototype&&SR.available){try{const o={langs:[lang],processLocally:true};let a=await SR.available(o);if(a=='downloadable'||a=='downloading'){SR.install&&SR.install(o).catch(()=>{});a='x'}local=a=='available'?1:0;
    if(!local&&lang!='en-US'){const b=await SR.available({langs:['en-US'],processLocally:true});if(b=='available')local=2}}catch(e){}}
  if(!local&&!navigator.onLine)return old.apply(this,arguments);startSR(local)}}
/* ---------- fast-fail requests + clear quota message ---------- */
const _f=window.fetch;window.fetch=function(u,o){const s=String(u);
 if(/generativelanguage\.googleapis\.com.*:streamGenerateContent/.test(s)&&o&&typeof o.body=='string'&&o.body.indexOf('responseModalities')<0&&!o.signal){const ab=new AbortController(),t=setTimeout(()=>ab.abort(),20000);
  return _f.call(this,u,Object.assign({},o,{signal:ab.signal})).then(r=>{clearTimeout(t);return r},e=>{clearTimeout(t);throw(e&&e.name=='AbortError')?Error('HTTP 503: Gemini took too long to answer'):e})}
 return _f.apply(this,arguments)};
const _st=window.step;window.step=async function(){try{return await _st.apply(this,arguments)}catch(e){const m=String(e&&e.message||e);
 if(/429|quota|RESOURCE_EXHAUSTED/i.test(m)){const t=/retry in ([\dhms]+)/i.exec(m);throw Error('Your Gemini key hit its free daily limit'+(t?' (resets in '+t[1]+')':'')+'. Add billing to the key or paste another key in Settings > API.')}if(/API key not valid|\b(401|403)\b/i.test(m))throw Error('Your API key was rejected. Paste a valid key in Settings > API & provider, or open Profile > Connection check.');if(/Failed to fetch|NetworkError|Load failed/i.test(m))throw Error('No connection to Google. Check your internet or VPN, then try again (Profile > Connection check).');if(/\b400\b/.test(m))throw Error(m.slice(0,220)+'  ·  Profile > Connection check can repair this.');throw e}};
try{if(!C.jx9){C.speed='fast';C.speak=true;C.jx9=1;sv('cfg',C)}}catch(e){}
/* ---------- profile switches ---------- */
const pk=$('jpk');if(pk){const mk=(l,get,set)=>{const b=el('button','','');const draw=()=>b.textContent=l+': '+(get()?'ON':'OFF');draw();b.onclick=()=>{set(!get());draw()};pk.prepend(b)};
 mk('SMOOTH LITE MODE',()=>document.body.classList.contains('lite'),v=>{LS('jxlite',v?'1':'0');setLite(v)});mk('SOUND EFFECTS',sfxOn,v=>{LS('jxsfx',v?'1':'0');if(v)sfx('on')})}
})();
