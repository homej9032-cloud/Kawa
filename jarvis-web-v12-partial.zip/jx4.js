/* JARVIS v5 · core: icons, fast male voice, auto-listen, particle globe, chat HUD, smooth intro */
(()=>{
const $=i=>document.getElementById(i),el=(t,c,h)=>{const e=document.createElement(t);c&&(e.className=c);h!=null&&(e.innerHTML=h);return e};
/* ---------- icons ---------- */
const IC={home:'M3 11l9-8 9 8M5 10v10h14V10M10 20v-6h4v6',user:'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21c0-4 4-7 8-7s8 3 8 7',mic:'M12 3a3 3 0 013 3v6a3 3 0 01-6 0V6a3 3 0 013-3zM6 11a6 6 0 0012 0M12 17v4',
 video:'M4 6h11a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V8a2 2 0 012-2zM17 10l5-3v10l-5-3',chat:'M4 5h16v11H9l-5 4z',trend:'M3 17l6-6 4 4 8-8M15 7h6v6',candles:'M6 3v18M4 8h4v8H4zM12 5v15M10 9h4v7h-4zM18 3v16M16 7h4v6h-4z',
 shield:'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM9 12l2 2 4-4',globe:'M12 3a9 9 0 100 18 9 9 0 000-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',cube:'M12 3l8 4.5v9L12 21l-8-4.5v-9zM12 12l8-4.5M12 12v9M12 12L4 7.5',
 eye:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 100-6 3 3 0 000 6z',bot:'M5 8h14v10H5zM12 4v4M9 13h.01M15 13h.01M3 12v3M21 12v3',note:'M6 3h9l4 4v14H6zM9 12h7M9 16h7',
 gear:'M12 9a3 3 0 100 6 3 3 0 000-6zM12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2',power:'M12 3v9M6.3 6.3a8 8 0 1011.4 0',up:'M6 15l6-6 6 6',x:'M6 6l12 12M18 6L6 18',
 pip:'M3 5h18v14H3zM12 12h8v6h-8z',spark:'M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z',play:'M7 4l13 8-13 8z',upload:'M12 16V4M7 9l5-5 5 5M4 20h16',cc:'M4 6h16v12H4zM9 10a2 2 0 100 4M16 10a2 2 0 100 4',
 table:'M3 5h18v14H3zM3 10h18M9 5v14M15 5v14',pie:'M12 3v9h9a9 9 0 11-9-9zM15 3a9 9 0 016 6h-6z',music:'M9 18V5l11-2v13M9 18a3 3 0 11-3-3 3 3 0 013 3zM20 16a3 3 0 11-3-3 3 3 0 013 3z',ear:'M7 9a5 5 0 0110 0c0 3-3 4-3 7a2 2 0 01-4 0M4 9',wand:'M4 20L16 8M14 4l1 2 2 1-2 1-1 2-1-2-2-1 2-1zM19 12l.7 1.3L21 14l-1.3.7L19 16l-.7-1.3L17 14l1.3-.7z',film:'M4 4h16v16H4zM8 4v16M16 4v16M4 9h4M4 15h4M16 9h4M16 15h4'};
const ic=(n,s)=>'<svg viewBox="0 0 24 24" width="'+(s||22)+'" height="'+(s||22)+'" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="'+IC[n]+'"/></svg>';
window.JXI=ic;window.jxApps=window.jxApps||{};
/* ---------- css ---------- */
const st=el('style');st.textContent=`
#cv,#halo{display:none!important}
#jxt button b{display:grid;place-items:center;font-size:0}#jxt button svg{width:22px;height:22px}
.tl button{height:68px;gap:7px;border-radius:16px;font:700 8px ui-monospace,monospace;letter-spacing:.14em;background:linear-gradient(165deg,rgba(79,227,255,.13),rgba(4,24,40,.72))}.tl button svg{width:24px;height:24px;color:#8defff}
.pill button svg,.chs button svg{width:18px;height:18px}.chs button{display:flex;align-items:center;gap:7px}.sbar button svg{width:22px;height:22px}
#jxs .rcol,#jxs .rc,#jxs .lb{display:none}
.rcol2{position:absolute;right:8px;top:25%;display:grid;gap:7px}.rcol2 button{width:46px;height:50px;clip-path:polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%);background:rgba(79,227,255,.2);border:0;color:#d8f8ff;display:grid;place-items:center}.rcol2 button:active{background:rgba(79,227,255,.5)}.rcol2 svg{width:21px;height:21px}
#jxsr{pointer-events:auto}
#jxcg{position:fixed;left:50%;top:15vh;width:min(84vw,340px);aspect-ratio:1;margin-left:calc(min(84vw,340px)/-2);z-index:1;pointer-events:none;transition:opacity .5s,transform .5s}#jxcg canvas{width:100%;height:100%;display:block}
body:not([data-p=chat]) #jxcg,body:not([data-p=chat]) #jxcr{display:none}
body[data-p=chat]:not(.empty) #jxcg{opacity:.22;transform:scale(.7) translateY(-8vh)}
body[data-p=chat]{background:radial-gradient(62% 38% at 50% 36%,rgba(16,90,160,.34),transparent 72%),linear-gradient(90deg,transparent 15%,rgba(0,0,0,.4) 15% 24%,transparent 24% 76%,rgba(0,0,0,.4) 76% 85%,transparent 85%),#020a12!important}
#jxcr{position:fixed;z-index:2;pointer-events:none}#jx3p{display:none}
@keyframes jxl{0%{transform:scale(2);opacity:.2}100%{transform:scale(1);opacity:1}}`;
document.head.append(st);
/* ---------- rebuild icons (no emoji) ---------- */
const tr=$('jxt');if(tr){[['home','home'],['prof','user'],['vid','video'],['chat','chat']].forEach(([p,n])=>{const b=tr.querySelector('[data-p='+p+'] b');b&&(b.innerHTML=ic(n))})}
const sb=(id,n,t)=>{const b=$(id);if(b)b.innerHTML=ic(n,18)+(t?'<span>'+t+'</span>':'')};
sb('jxm','mic');sb('jxpw','power');sb('jxcv','up');sb('jxsol','cube','SOLID 3D');sb('jxfl','pip','FLOAT');if($('jxg2'))$('jxg2').innerHTML=ic('gear',22);
const wk=$('jxw');if(wk)new MutationObserver(()=>{if(/[^\x00-\x7f]/.test(wk.textContent)&&!wk.querySelector('svg'))wk.textContent=wk.textContent.replace(/[^\x00-\x7f]\s*/g,'')}).observe(wk,{childList:true,characterData:true,subtree:true});
const TL=[['chat','CHAT',()=>jxGo('chat')],['mic','SPEAK',()=>jxGo('speak')],['film','STUDIO',()=>jxApps.studio&&jxApps.studio()],['candles','MARKETS',()=>jxApps.markets&&jxApps.markets()],['shield','SCAN',()=>jxApps.scan&&jxApps.scan()],['globe','EARTH',()=>jxApps.earth&&jxApps.earth()],
 ['spark','MEMORY',()=>$('sMem').click()],['eye','VISION',()=>{jxGo('chat');$('bCam').click()}],['bot','AGENTS',()=>$('bAg').click()],['note','NOTES',()=>$('sNotes').click()]];
const tl=$('jxtl');if(tl){tl.innerHTML='';tl.append(...TL.map(([i,l,f])=>{const b=el('button','',ic(i,24)+l);b.onclick=f;return b}))}
const sp0=$('jxs');if(sp0){const rc=el('div','rcol2');[['shield','scan'],['candles','markets'],['film','studio'],['globe','earth'],['gear','set']].forEach(([i,a])=>{const b=el('button','',ic(i,21));b.onclick=()=>a=='set'?$('bSet').click():jxApps[a]&&jxApps[a]();rc.append(b)});sp0.append(rc)}
const hb=el('button','','<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><path d="M5 10c0-4 3-7 7-7s7 3 7 7v5c0 3-2 6-4 6H9c-2 0-4-3-4-6z"/><path d="M7 11.5h4l-.5 2H7zM17 11.5h-4l.5 2H17z"/></svg>');hb.id='bIron';hb.setAttribute('aria-label','Iron Man');

/* ---------- chest reactor = centre speak button ---------- */
if($('jxsr'))$('jxsr').onclick=()=>$('jxm').click();
/* ---------- fast male voice + short answers + auto listen ---------- */
try{if(!C.jx5){C.voice='Charon';C.speed='fast';C.speak=true;C.style='short';C.jx5=1;sv('cfg',C)}}catch(e){}
const BR="\n\nVOICE-FIRST STYLE (highest priority): you are JARVIS in a fast spoken conversation. Reply in at most 2 short sentences (under 35 words) unless the user explicitly asks for detail. No preamble, no repeating the question, no lists when speaking. When explaining numbers, comparisons, trends, schedules or any data, call show_chart or show_table to display it and speak only a one-sentence summary. After a phone action just say 'Done, boss.' or a few words. For current events, prices, news, comparisons or anything the user asks to research or explain in depth, call deep_research, then speak two short sentences. Always address the user as boss.";
const _step=window.step;window.step=function(h,onT,sys,bg){return _step.call(this,h,onT,(sys||'')+BR,bg)};
let idle0=0;setInterval(()=>{if(document.body.dataset.p!='speak'||!C.hf||document.hidden)return idle0=0;
 const idle=!sp&&!busy&&!listening&&(typeof cur=='function'?cur()=='idle':true);if(!idle)return idle0=0;if(!idle0)idle0=Date.now();else if(Date.now()-idle0>600){idle0=0;listen()}},250);
/* ---------- particle globe (WebGL points, ~11k particles, Saturn ring) driven by the voice spectrum ---------- */
const JG=(()=>{const c=el('canvas');let gl,pr,U={},n=0,ok=0,lod=1,NP0=0,NR0=0,bd=new Float32Array(16),FB=new Uint8Array(128),rot=0,lt=0;
 const VS=`attribute vec4 a;attribute vec2 b;uniform float t,rot,lv,k,ps;uniform float bd[16];varying float vf,vz;
 void main(){vec3 p=a.xyz,q;float ring=b.x,lon=atan(p.z,p.x)/6.2832+.5,v=bd[int(floor(lon*15.99))];
 if(ring<.5){float r=1.+.3*v+.05*lv*sin(p.y*8.+t*4.+a.w*6.);q=p*r;float c=cos(rot),s=sin(rot);q=vec3(q.x*c+q.z*s,q.y,-q.x*s+q.z*c);}
 else{float R=1.5+1.05*b.y,an=atan(p.z,p.x)+rot*.35*(2.-b.y),w=.05*sin(an*6.+t*3.)+.3*v*sin(an*3.-t*5.);q=vec3(cos(an)*R,w+(a.w-.5)*.05,sin(an)*R);}
 float c1=cos(.45),s1=sin(.45);q=vec3(q.x,q.y*c1-q.z*s1,q.y*s1+q.z*c1);float c2=cos(-.22),s2=sin(-.22);q=vec3(q.x*c2-q.y*s2,q.x*s2+q.y*c2,q.z);
 gl_Position=vec4(q.x*k,q.y*k,-q.z*.1,1.);vz=(q.z+2.6)/5.2;vf=ring<.5?q.y*.4+.5:.3+.35*b.y;gl_PointSize=(1.2+2.*vz+v*2.4)*ps;}`;
 const FS=`precision mediump float;varying float vf,vz;void main(){vec2 d=gl_PointCoord-.5;float r=length(d);if(r>.5)discard;float a=smoothstep(.5,.12,r)*(.3+.7*vz);
 vec3 col=mix(vec3(.06,.3,1.),vec3(.32,.92,1.),vf)+vec3(.5,.7,1.)*smoothstep(.22,0.,r)*.45;gl_FragColor=vec4(col*a,a);}`;
 function init(){try{gl=c.getContext('webgl',{antialias:false,alpha:true,powerPreference:'low-power'});if(!gl)return 0;
  const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))console.error('globe shader: '+gl.getShaderInfoLog(o));return o};
  pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pr);gl.useProgram(pr);
  const NP=(navigator.deviceMemory&&navigator.deviceMemory<=3)?4500:7000,NR=Math.round(NP*.28);NP0=NP;NR0=NR;n=NP+NR;const A=new Float32Array(n*4),B=new Float32Array(n*2);
  const pm=Array.from({length:NP},(_,i)=>i);for(let i=NP-1;i>0;i--){const q=Math.floor(Math.random()*(i+1));[pm[i],pm[q]]=[pm[q],pm[i]]}
  for(let i=0;i<NP;i++){const jj=pm[i],y=1-2*(jj+.5)/NP,r=Math.sqrt(1-y*y),t=jj*2.399963;A.set([Math.cos(t)*r,y,Math.sin(t)*r,Math.random()],i*4)}
  for(let i=0;i<NR;i++){const an=Math.random()*6.2832,band=Math.floor(Math.random()*5)/5,rr=Math.min(1,band+Math.random()*.12);A.set([Math.cos(an),0,Math.sin(an),Math.random()],(NP+i)*4);B.set([1,rr],(NP+i)*2)}
  [['a',A,4],['b',B,2]].forEach(([k,d,z])=>{const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,d,gl.STATIC_DRAW);const l=gl.getAttribLocation(pr,k);gl.enableVertexAttribArray(l);gl.vertexAttribPointer(l,z,gl.FLOAT,false,0,0)});
  'tm rot lv k ps'.split(' ').forEach(k=>U[k]=gl.getUniformLocation(pr,k=='tm'?'t':k));U.bd=gl.getUniformLocation(pr,'bd');gl.enable(gl.BLEND);gl.blendFunc(1,1);return ok=1}catch(e){console.error('globe init: '+e.message);return 0}}
 function bands(s,k){let an=null;try{an=sp?ana:listening?mana:null}catch(e){}let has=0;if(an&&an.getByteFrequencyData){try{an.getByteFrequencyData(FB);has=1}catch(e){}}
  for(let j=0;j<16;j++){let v=0;if(has){for(let q=0;q<5;q++)v+=FB[1+j*5+q];v=Math.min(1,v/5/190)}else v=k*(.45+.45*Math.sin(s*5+j*1.3));bd[j]+=(v-bd[j])*(v>bd[j]?.55:.14)}}
 return{c,setLod(v){lod=v},render(px,s,k){if(!ok&&!init())return c;if(px&&c.width!=px)c.width=c.height=px;bands(s,k);const dt=Math.min(.05,s-lt||.016);lt=s;rot+=dt*(.35+k*.9);
  gl.viewport(0,0,c.width,c.height);gl.clearColor(0,0,0,0);gl.clear(16384);gl.uniform1f(U.tm,s);gl.uniform1f(U.rot,rot);gl.uniform1f(U.lv,k);gl.uniform1f(U.k,.37);gl.uniform1f(U.ps,c.width/320);gl.uniform1fv(U.bd,bd);gl.drawArrays(0,0,Math.floor(NP0*lod));gl.drawArrays(0,NP0,Math.floor(NR0*lod));return c}}})();
window.JG=JG;
const cg=el('div');cg.id='jxcg';cg.append(JG.c);document.body.append(cg);const cr=el('div','rul');cr.id='jxcr';document.body.append(cr);
let lastChat=0,lt=0;
function cloop(t){requestAnimationFrame(cloop);if(document.body.dataset.p!='chat'||document.hidden||t-lt<(document.body.classList.contains('lite')?42:30))return;lt=t;
 const empty=document.body.classList.contains('empty'),k=Math.min(1,(window.jxLevel?jxLevel():0)*1.4);JG.render(Math.round(Math.min(devicePixelRatio||1,document.body.classList.contains('lite')?1:1.4)*Math.min(innerWidth*.84,340)*(empty?1:.7)),t/1000,k);lastChat=t}
requestAnimationFrame(cloop);
window.jxOrb=(g,S,s,k)=>{const c=JG.render(performance.now()-lastChat<120?0:256,s,k);g.clearRect(0,0,S,S);g.drawImage(c,0,0,S,S)};
/* ---------- smooth arc-reactor intro (canvas 2D, compositor-only fly-in) ---------- */
function intro(){const D=Math.min(devicePixelRatio||1,1.25),S=Math.min(innerWidth*.78,300),o=el('div','','<canvas></canvas><div id="jxit">J.A.R.V.I.S<small>INITIALIZING</small></div>');o.id='jxi';document.body.append(o);
 const cv=o.firstChild,W=Math.round(S*D);cv.width=cv.height=W;cv.style.cssText='width:'+S+'px;height:'+S+'px;will-change:transform;transition:transform 1s cubic-bezier(.65,0,.2,1)';const x=cv.getContext('2d'),u=W/2;
 const sp=el('canvas');sp.width=sp.height=96;{const q=sp.getContext('2d'),r=q.createRadialGradient(48,48,0,48,48,48);r.addColorStop(0,'rgba(225,255,255,1)');r.addColorStop(.28,'rgba(79,227,255,.5)');r.addColorStop(1,'rgba(79,227,255,0)');q.fillStyle=r;q.fillRect(0,0,96,96)}
 const P=Array.from({length:64},()=>({a:Math.random()*6.283,r:.5+Math.random()*.5,s:(.3+Math.random())*(Math.random()<.5?1:-1)})),waves=[],t0=performance.now();let fly=0,last=0,done=0;
 const bp=(f,d,v)=>{try{ac=ac||new(window.AudioContext||webkitAudioContext)();const s=ac.createOscillator(),g=ac.createGain();s.frequency.value=f;g.gain.setValueAtTime(v||.06,ac.currentTime);g.gain.exponentialRampToValueAtTime(.0001,ac.currentTime+(d||.12));s.connect(g);g.connect(ac.destination);s.start();s.stop(ac.currentTime+(d||.12))}catch(e){}};
 [250,560,870].forEach((t,i)=>setTimeout(()=>{bp(500+i*180);waves.push(performance.now())},t));setTimeout(()=>{bp(880,.5,.08);waves.push(performance.now());const s=$('jxit').lastChild;s&&(s.textContent='SYSTEM ONLINE')},1250);
 const finish=()=>{if(done)return;done=1;const h=$('jxhr');if(h){h.classList.remove('hide');h.firstChild&&(h.firstChild.style.animation='jxl .7s ease-out')}o.remove();window.jxWave&&setTimeout(jxWave,300)};
 function frame(t){if(done)return;requestAnimationFrame(frame);if(t-last<30)return;last=t;const T=(t-t0)/1000,b=Math.min(1,T/1.1),on=Math.min(1,T/1.3);x.clearRect(0,0,W,W);x.save();x.translate(u,u);
  x.globalAlpha=Math.min(1,.25+.75*b)*(.88+.12*Math.sin(T*9));x.drawImage(sp,-u*1.15,-u*1.15,u*2.3,u*2.3);x.globalAlpha=1;
  x.lineWidth=2*D;x.strokeStyle='rgba(127,240,255,.9)';x.beginPath();x.arc(0,0,u*.92,-1.571,-1.571+6.283*b);x.stroke();
  x.save();x.rotate(-T*.7);x.setLineDash([3*D,7*D]);x.globalAlpha=.7;x.beginPath();x.arc(0,0,u*.82,0,6.283);x.stroke();x.restore();
  x.save();x.rotate(T*(.4+on));for(let i=0;i<10;i++){x.save();x.rotate(i*.6283);x.globalAlpha=b*10>i?.95:.1;x.fillStyle='rgba(79,227,255,.3)';x.beginPath();x.moveTo(-u*.09,-u*.74);x.lineTo(u*.09,-u*.74);x.lineTo(u*.07,-u*.5);x.lineTo(-u*.07,-u*.5);x.closePath();x.fill();x.stroke();x.restore()}x.restore();
  x.globalAlpha=Math.min(1,b*1.4);x.lineWidth=3*D;x.beginPath();x.arc(0,0,u*.38,0,6.283);x.stroke();x.lineWidth=1.5*D;x.beginPath();x.arc(0,0,u*.3,0,6.283);x.stroke();
  x.save();x.rotate(T*.9);x.beginPath();for(let i=0;i<3;i++){const a=i*2.094-1.571;x.lineTo(Math.cos(a)*u*.24,Math.sin(a)*u*.24)}x.closePath();x.stroke();x.restore();
  x.fillStyle='#eaffff';x.globalAlpha=Math.min(1,on+.3);x.beginPath();x.arc(0,0,u*(.1+.02*Math.sin(T*10)),0,6.283);x.fill();
  for(let i=waves.length-1;i>=0;i--){const a=(performance.now()-waves[i])/700;if(a>1){waves.splice(i,1);continue}x.globalAlpha=(1-a)*.8;x.lineWidth=2*D;x.beginPath();x.arc(0,0,u*(.25+a*.75),0,6.283);x.stroke()}
  x.globalAlpha=.8;x.fillStyle='#8ff3ff';for(const p of P){const a=p.a+T*p.s*(1+on),r=u*p.r*(.9+.1*Math.sin(T*3+p.a));x.fillRect(Math.cos(a)*r,Math.sin(a)*r,1.6*D,1.6*D)}
  x.restore();
  if(T>1.9&&!fly){fly=1;const h=$('jxhr');let tx=innerWidth/2,ty=innerHeight*.36,tw=64;if(h){const r=h.getBoundingClientRect();if(r.width>4){tx=r.left+r.width/2;ty=r.top+r.height/2;tw=r.width}}
   const b0=cv.getBoundingClientRect();cv.style.transform='translate('+(tx-b0.left-b0.width/2)+'px,'+(ty-b0.top-b0.height/2)+'px) scale('+(tw/b0.width)+')';o.classList.add('fly');bp(660,.3,.05)}
  if(T>2.9)finish()}
 requestAnimationFrame(frame);setTimeout(finish,7000)}
try{intro()}catch(e){const h=$('jxhr');h&&h.classList.remove('hide')}
})();
