/* JARVIS v4 · streaming Gemini voice (starts in ~1 s, no device voice), image-2 HUD for Speak, quota message */
(()=>{
const $=i=>document.getElementById(i),BASE='https://generativelanguage.googleapis.com/v1beta/';
/* ---- streaming Gemini TTS: audio plays while it is still being generated ---- */
function trim(x,r){const T=.012,G=Math.floor(r*.2),W=Math.floor(r*.22);let e=x.length;while(e>0&&Math.abs(x[e-1])<T)e--;let run=0;
 for(let i=e-1;i>0&&e-i<r*.7;i--){if(Math.abs(x[i])<T){if(++run>=G){if(e-(i+run)<W){e=i;while(e>0&&Math.abs(x[e-1])<T)e--}break}}else run=0}return x.slice(0,e)}
const sl=ms=>new Promise(r=>setTimeout(r,ms));let ttsAt=0;
async function stream(m,text){const gap=ttsAt+650-Date.now();if(gap>0)await sl(gap);ttsAt=Date.now();
 const go=()=>fetch(BASE+'models/'+m+':streamGenerateContent?alt=sse',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':K.g},
  body:JSON.stringify({contents:[{parts:[{text}]}],generationConfig:{responseModalities:['AUDIO'],speechConfig:{voiceConfig:{prebuiltVoiceConfig:{voiceName:C.voice}}}}})});let r=await go();if(r.status==429){const tx=await r.text(),w=/retry in ([\d.]+)s/i.exec(tx);if(w&&+w[1]<=20){await sl(Math.ceil(+w[1]*1000)+300);r=await go()}else throw Error('HTTP 429: '+tx.slice(0,300))}
 if(!r.ok)throw Error('HTTP '+r.status+': '+(await r.text()).slice(0,300));
 const o={stm:1,q:[],done:false,rate:24000,err:null},rd=r.body.getReader(),dec=new TextDecoder();let buf='',ok;const fp=new Promise(z=>ok=z);
 (async()=>{try{for(;;){const{value,done}=await rd.read();if(done)break;buf+=dec.decode(value,{stream:true});let i;
  while((i=buf.indexOf('\n'))>=0){const ln=buf.slice(0,i).trim();buf=buf.slice(i+1);if(ln.indexOf('data:')!=0)continue;
   const j=JSON.parse(ln.slice(5)),p=(((j.candidates||[{}])[0].content||{}).parts||[]).find(x=>x.inlineData||x.inline_data);
   if(p){const d=p.inlineData||p.inline_data;o.rate=+((/rate=(\d+)/.exec(d.mimeType||d.mime_type||'')||[])[1])||24000;o.q.push(d.data);ok(o)}}}}catch(e){o.err=e}o.done=true;ok(o)})();
 await fp;if(!o.q.length&&!o.done)throw Error('no audio');if(!o.q.length)throw Error(o.err?o.err.message:'no audio returned');return o}
const _o=window.ttsOne;
window.ttsOne=async(m,t,a)=>{try{return await stream(m,t)}catch(e){if(/\b(429|401|403)\b|quota|API key/i.test(String(e.message)))throw e;return _o(m,t,a)}};
function pcm(b64,carry){const bin=atob(b64),u=new Uint8Array(carry.length+bin.length);u.set(carry);for(let i=0;i<bin.length;i++)u[carry.length+i]=bin.charCodeAt(i);
 const m=u.length&~1,s=new Int16Array(u.buffer.slice(0,m)),f=new Float32Array(m>>1);for(let i=0;i<f.length;i++)f[i]=s[i]/32768;return{f,c:u.slice(m)}}
function playStream(o,my){return new Promise(res=>{ac=ac||new(window.AudioContext||webkitAudioContext)();ac.resume();
 const gn=ac.createGain(),an=ac.createAnalyser();an.fftSize=256;an.smoothingTimeConstant=.5;abuf=new Uint8Array(256);gn.connect(an);an.connect(ac.destination);ana=an;sp=true;
 const r=o.rate,H=Math.floor(r*.5),srcs=[];let nt=0,pend=new Float32Array(0),carry=new Uint8Array(0),first=1,fin=0,fo=0;
 const stop=()=>{srcs.forEach(s=>{try{s.stop()}catch(e){}});try{gn.disconnect()}catch(e){}},end=()=>{if(!fin){fin=1;res()}};src={stop};
 const put=x=>{if(!x.length)return;const b=ac.createBuffer(1,x.length,r);b.copyToChannel(x,0);const s=ac.createBufferSource();s.buffer=b;s.connect(gn);const t=Math.max(ac.currentTime+.04,nt);s.start(t);nt=t+b.duration;srcs.push(s)};
 const tick=()=>{if(my!=gid){stop();return end()}
  while(o.q.length){const d=pcm(o.q.shift(),carry);carry=d.c;const m=new Float32Array(pend.length+d.f.length);m.set(pend);m.set(d.f,pend.length);pend=m;
   if(first&&pend.length){const n=Math.floor(r*.006);for(let i=0;i<n&&i<pend.length;i++)pend[i]*=i/n;first=0}
   if(pend.length>H){put(pend.subarray(0,pend.length-H));pend=pend.slice(pend.length-H)}}
  if(o.done&&!o.q.length){if(!fo){fo=1;const x=trim(pend,r),n=Math.min(x.length,Math.floor(r*.035));for(let i=0;i<n;i++)x[x.length-1-i]*=i/n;put(x)}if(ac.currentTime>=nt-.01)return end()}
  setTimeout(tick,20)};tick()})}
const _p=window.playBuf;window.playBuf=(b,t,my)=>b&&b.stm?playStream(b,my):_p(b,t,my);
/* ---- clear message when the Gemini free quota is used up (no device voice, by choice) ---- */
window.voiceErr=e=>{const g=String(e&&e.message||e);vwarn=Date.now();const m=/retry in ((?:\d+h)?(?:\d+m)?[\d]*)/i.exec(g);
 pp(/429|quota|RESOURCE_EXHAUSTED/i.test(g)?'Gemini voice quota is used up'+(m?' (back in '+m[1]+')':'')+'. A pay-as-you-go Gemini key gives unlimited fast voice.':/API key|401|403/i.test(g)?'Gemini voice: check your API key':'Gemini voice failed: '+g.slice(0,90))};
/* ---- Speak screen = replica of the blue Iron Man HUD ---- */
const st=document.createElement('style');st.textContent=`#jxs .lb,#jxs .rc{display:none}

#jxs{background:radial-gradient(60% 46% at 50% 42%,rgba(16,100,160,.38),transparent 72%),linear-gradient(90deg,transparent 17%,rgba(0,0,0,.4) 17% 25%,transparent 25% 75%,rgba(0,0,0,.4) 75% 83%,transparent 83%),#030f1a}
.lbars{position:absolute;left:8px;top:47%;display:grid;gap:9px;width:40px}.lbars i{display:block;height:3px;width:var(--w);background:#7ff0ff;box-shadow:0 0 6px #4fe3ff;position:relative}.lbars i::after{content:'';position:absolute;right:-9px;top:-1px;width:5px;height:5px;background:#ff5a4f}
.rcol{position:absolute;right:8px;top:25%;display:grid;gap:6px}.rcol button{width:44px;height:48px;clip-path:polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%);background:rgba(79,227,255,.22);border:0;color:#d8f8ff;font-size:17px}.rcol button:active{background:rgba(79,227,255,.55)}
.ctr{position:absolute;bottom:262px;left:0;right:0;display:flex;justify-content:center;align-items:center;gap:9px;font-size:8px;letter-spacing:.18em;color:#9fdcff;pointer-events:none}.ctr img{width:32px;filter:grayscale(1) brightness(1.5);opacity:.85}
.ctr div{width:58px}.ctr i{display:block;height:7px;margin-top:4px;background:repeating-linear-gradient(90deg,#4fe3ff 0 3px,transparent 3px 5px);transform:skewX(-30deg)}.ctr b{display:block;font-size:10px;font-weight:700;color:#e9fbff;margin-top:3px;letter-spacing:.2em}`;document.head.append(st);
const pg=$('jxs');if(pg){const d=document.createElement('div');
 d.innerHTML='<div class="lbars">'+[0,1,2,3,4,5].map(i=>'<i style="--w:'+(55+(i*37)%38)+'%"></i>').join('')+'</div><div class="rcol"><button data-a="m">◉</button><button data-a="s">⬡</button><button data-a="v">🎬</button><button data-a="c">💬</button><button data-a="g">⚙</button></div><div class="ctr"><div>SIGNAL<i></i></div><img src="logo.svg" alt=""><div>BATTERY<i></i></div><span id="jxdt" style="position:absolute;top:36px;font-size:10px;letter-spacing:.3em;color:#cfefff"></span></div>';
 d.onclick=e=>{const b=e.target.closest('button');if(!b)return;({m:()=>$('jxm').click(),s:()=>$('jxsol').click(),v:()=>document.querySelector('#jxt [data-p=vid]').click(),c:()=>jxGo('chat'),g:()=>$('bSet').click()})[b.dataset.a]()};pg.append(...d.children);
 setInterval(()=>{const x=$('jxd');x&&($('jxdt').textContent=x.textContent)},2000)}
})();
