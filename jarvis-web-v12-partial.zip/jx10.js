/* JARVIS v8 · reliability: tools never stay off, connection doctor with one-tap model fix */
(()=>{
const $=i=>document.getElementById(i),el=(t,c,h)=>{const e=document.createElement(t);c&&(e.className=c);h!=null&&(e.innerHTML=h);return e},sleep=ms=>new Promise(r=>setTimeout(r,ms)),ic=n=>window.JXI(n);
/* tools were switched off for the whole session after any single error: turn them back on at every new message */
const _turn=window.turn;window.turn=async function(){try{noTools=false}catch(e){}return _turn.apply(this,arguments)};
/* ---------- connection doctor ---------- */
const o=el('div','ovl','<div class="oh"><b>CONNECTION CHECK</b><button class="ox">'+ic('x')+'</button></div><div class="gl"><div id="dcl" class="lg"></div></div><div class="chp"><button id="dcr" class="on">RUN AGAIN</button><button id="dcu" style="display:none">USE BEST MODEL</button><button id="dcv">TEST VOICE (1 request)</button></div><div class="mut" id="dcn" style="color:#7fb0c4;font:600 11px/1.6 ui-monospace,monospace;margin:8px 2px"></div>');o.id='jxdoc';document.body.append(o);
o.querySelector('.ox').onclick=()=>o.classList.remove('on');
const G='https://generativelanguage.googleapis.com/v1beta/',row=(c,t,s)=>{const d=el('div','','<span>'+t+'</span><b class="'+c+'">'+s+'</b>');$('dcl').append(d);return d};
const why=(st,m)=>{m=String(m||'');if(st==429){const w=/retry in ([\dhms.]+)/i.exec(m);return /per.?minute|rpm/i.test(m)?'Too many requests per minute: wait a few seconds':'Daily free limit used up'+(w?' · resets in '+w[1].replace(/\.\d+/,''):'')}if(st==400&&/API key/i.test(m))return 'API key not valid';if(st==403||st==401)return 'Key rejected or not allowed';if(st==404)return 'Model not available for this key';if(st>=500)return 'Google is busy, try again';return (m.slice(0,70)||'Error')};
async function post(model,body,ms){const ab=new AbortController(),t=setTimeout(()=>ab.abort(),ms||12000);try{const r=await fetch(G+'models/'+model+':generateContent',{method:'POST',headers:{'x-goog-api-key':K.g,'content-type':'application/json'},body:JSON.stringify(body),signal:ab.signal});const j=await r.json().catch(()=>({}));return{st:r.status,j}}finally{clearTimeout(t)}}
let best=null;
async function run(){$('dcl').innerHTML='';$('dcu').style.display='none';$('dcn').textContent='';best=null;
 row('','Internet',navigator.onLine?'<span class="ok">ONLINE</span>':'<span class="bd">OFFLINE</span>');
 if(C.prov!='gemini'){row('wn','Provider',C.prov+' (custom API)');$('dcn').textContent='This check tests Gemini keys. Switch provider to Gemini in Settings to use it.';return}
 if(!K.g){row('bd','API key','MISSING');$('dcn').textContent='Open Settings > API & provider and paste your Gemini key.';return}
 let names=[];const r0=row('','API key','checking…');
 try{const t0=performance.now(),r=await fetch(G+'models?pageSize=200',{headers:{'x-goog-api-key':K.g}}),j=await r.json().catch(()=>({}));
  if(!r.ok){r0.lastChild.className='bd';r0.lastChild.textContent=why(r.status,j.error&&j.error.message);$('dcn').textContent=r.status==429?'Your key has no requests left right now. Wait for the reset, add billing, or paste another key.':'Paste a valid key in Settings > API & provider.';return}
  names=(j.models||[]).filter(m=>(m.supportedGenerationMethods||[]).includes('generateContent')).map(m=>m.name.replace(/^models\//,''));r0.lastChild.className='ok';r0.lastChild.textContent='VALID · '+Math.round(performance.now()-t0)+' ms · '+names.length+' models'}
 catch(e){r0.lastChild.className='bd';r0.lastChild.textContent='Cannot reach Google';$('dcn').textContent='Check your internet, turn off any VPN or ad-blocker for this app, then run again.';return}
 const bad=n=>/image|tts|audio|live|embed|robot|computer|learnlm|gemma|exp|thinking|vision/.test(n),pref=['gemini-2.5-flash','gemini-2.5-flash-lite','gemini-2.0-flash','gemini-flash-latest','gemini-flash-lite-latest'],list=[...new Set([MODEL,...pref,...names.filter(n=>/flash/.test(n)&&!bad(n))].filter(n=>n&&names.includes(n)))].slice(0,6);
 for(const m of list){const d=row('',m+(m==MODEL?' (current)':''),'testing…');const t0=performance.now();try{const {st,j}=await post(m,{contents:[{role:'user',parts:[{text:'Reply with OK'}]}],generationConfig:{maxOutputTokens:16}});
  if(st==200){d.lastChild.className='ok';d.lastChild.textContent='WORKS · '+Math.round(performance.now()-t0)+' ms';if(!best)best={m,ms:performance.now()-t0}}else{d.lastChild.className='bd';d.lastChild.textContent=why(st,j.error&&j.error.message)}}catch(e){d.lastChild.className='bd';d.lastChild.textContent=e.name=='AbortError'?'Too slow (12 s)':'Network error'}}
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;let mic='unknown';try{mic=(await navigator.permissions.query({name:'microphone'})).state}catch(e){}
 row('','Microphone',mic=='granted'?'<span class="ok">ALLOWED</span>':mic=='denied'?'<span class="bd">BLOCKED</span>':'<span class="wn">ASK ON USE</span>');row('','Speech recognition',SR||window.Phone?'<span class="ok">AVAILABLE</span>':'<span class="bd">NOT SUPPORTED IN THIS BROWSER</span>');
 row('','Real 3D model',document.querySelector('.fig.g3')?'<span class="ok">ACTIVE</span>':'<span class="wn">NORMAL FIGURE (3D button on Home/Speak)</span>');row('','Phone control',window.Phone?(Phone.ready&&Phone.ready()?'<span class="ok">ACTIVE</span>':'<span class="wn">TURN ON ACCESSIBILITY</span>'):'<span class="wn">BROWSER: ONE-TAP ACTIONS ONLY</span>');
 if(best){$('dcn').textContent=best.m==MODEL?'Everything needed for answers is working. Current model: '+MODEL+'.':'Your current model is not answering, but '+best.m+' is. Tap USE BEST MODEL.';if(best.m!=MODEL)$('dcu').style.display=''}
 else $('dcn').textContent='No model answered. Most likely your free daily limit is used up for every model: wait for the reset, add billing to the key, or paste another key.'}
$('dcr').onclick=run;
$('dcu').onclick=()=>{if(!best)return;MODEL=best.m;try{ls.m=best.m;MODELS=[best.m,...(MODELS||[]).filter(n=>n!=best.m)]}catch(e){}$('dcn').textContent='Now using '+best.m+'.';$('dcu').style.display='none'};
$('dcv').onclick=async()=>{const n=$('dcn');n.textContent='Testing voice…';try{const x=await tts('Voice check complete, boss.',gid);if(!x)throw Error('no audio');await playBuf(x,'',gid);n.textContent='Voice works.'}catch(e){n.textContent='Voice failed: '+String(e.message||e).slice(0,120)}};
const open=()=>{o.classList.add('on');o.scrollTop=0;run()};window.jxApps=window.jxApps||{};jxApps.doctor=open;
const pk=$('jpk');if(pk){const b=el('button','','CONNECTION CHECK');b.onclick=open;pk.prepend(b)}

/* tray centre button: the arc reactor fills the whole circle */
const sx=document.createElement('style');sx.textContent=`#jxt .mid{display:block;position:relative;padding:0;overflow:hidden}#jxt .mid .ar{position:absolute;left:5px;top:5px;right:5px;bottom:5px;width:auto;height:auto}#jxt .mid .ar .h{inset:-12%;opacity:.55}#jxt .mid .ar svg{width:100%;height:100%}`;document.head.append(sx);
})();
