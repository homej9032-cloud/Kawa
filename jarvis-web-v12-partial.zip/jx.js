/* JARVIS v2 · bottom tray, HUD Home / Speak / Profile, solid rigged Iron Man, arc-reactor intro, offline speech, floating orb (PiP), Video Studio */
(()=>{
const $=i=>document.getElementById(i),E=(t,c,h)=>{const e=document.createElement(t);c&&(e.className=c);h!=null&&(e.innerHTML=h);return e},TAU=Math.PI*2;
let page='home',L=0,pose=0,solid=true,PIP=0,pv=null,hfPrev=null,noLocal=0,raf=0,last=0;
/* ---------- arc reactor (svg + glow layer, driven by --o / --s) ---------- */
const AR=()=>{let s='<div class="ar"><i class="h"></i><svg viewBox="-100 -100 200 200" fill="none" stroke="#7ff0ff" stroke-width="2.2"><circle r="97" stroke-opacity=".7"/><circle r="88" stroke-dasharray="3 5" class="r2"/><g class="r1" fill="rgba(79,227,255,.22)">';
for(let i=0;i<10;i++)s+=`<path d="M-9-82L9-82L7-56L-7-56Z" transform="rotate(${i*36})"/>`;
return s+'</g><circle r="48" stroke-width="3"/><circle r="40" stroke-opacity=".6"/><path d="M0-30L26 15L-26 15Z" stroke-opacity=".8"/><circle r="15" fill="#e8feff" stroke="none"/></svg></div>'};
const glow=(el,o,s)=>{const a=el.firstChild;a&&(a.style.setProperty('--o',o),a.style.setProperty('--s',s))};
const hex=(()=>{let s='';[[0,0],[1,0],[2,0],[.5,.87],[1.5,.87],[1,1.73],[2,1.73]].forEach(([x,y])=>s+=`<polygon transform="translate(${x*17+10} ${y*17+10})" points="8,0 4,6.9 -4,6.9 -8,0 -4,-6.9 4,-6.9"/>`);return`<svg class="hx" viewBox="0 0 60 50" fill="none" stroke="#7ff0ff" stroke-width=".8">${s}</svg>`})();
const globe='<svg class="gb" viewBox="-20 -20 40 40" fill="none" stroke="#7ff0ff" stroke-width=".5"><circle r="18"/><ellipse rx="18" ry="6"/><ellipse rx="6" ry="18"/><ellipse rx="12" ry="18"/><ellipse rx="18" ry="12"/></svg>';
/* ---------- css ---------- */
const st=E('style');st.textContent=`
#av,#bFace,#spl>*{display:none!important}
body{--jc:#4fe3ff}
.jxp{position:fixed;inset:0;z-index:4;display:none;background:radial-gradient(90% 60% at 50% 38%,#08263e,#02060c 74%);color:#bdeeff;font:700 10px ui-monospace,monospace;letter-spacing:.14em;overflow:hidden}
body[data-p=home] #jxh,body[data-p=speak] #jxs,body[data-p=prof] #jxf{display:block}
body:not([data-p=chat]) :is(#top,#msgs,#hello,#dock,#halo,#cv,#fdT,#fdB,#vid){display:none!important}
body[data-p=chat] #dock{bottom:calc(max(8px,env(safe-area-inset-bottom)) + 74px)}body[data-p=chat] #msgs{padding-bottom:250px}
#jxt{position:fixed;left:10px;right:10px;bottom:max(8px,env(safe-area-inset-bottom));height:62px;z-index:5;display:flex;align-items:center;justify-content:space-around;border-radius:31px;background:rgba(3,14,26,.92);border:1px solid rgba(79,227,255,.45);box-shadow:0 0 24px rgba(79,227,255,.25),inset 0 0 18px rgba(79,227,255,.08)}
#jxt button{background:none;border:0;color:#7fb0c4;font:800 8.5px ui-monospace,monospace;letter-spacing:.12em;display:grid;gap:2px;place-items:center;width:56px;height:54px}#jxt button b{font-size:19px;font-weight:400}#jxt button.on{color:var(--jc);text-shadow:0 0 10px var(--jc)}
#jxt .mid{width:68px;height:68px;margin-top:-34px;border-radius:50%;background:#02101a;border:1px solid var(--jc);box-shadow:0 0 24px rgba(79,227,255,.7);padding:9px}
.ar{position:relative;width:100%;height:100%;--o:.55;--s:1}.ar svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible}
.ar .h{position:absolute;inset:-45%;border-radius:50%;background:radial-gradient(circle,rgba(215,253,255,.95),rgba(79,227,255,.4) 30%,transparent 62%);opacity:var(--o);transform:scale(var(--s));pointer-events:none}
.ar .r1,.ar .r2{transform-origin:0 0;animation:jxs 16s linear infinite}.ar .r2{animation-duration:10s;animation-direction:reverse}@keyframes jxs{to{transform:rotate(1turn)}}
.rul{position:absolute;left:14px;right:14px;top:calc(max(10px,env(safe-area-inset-top)) + 4px);height:12px;border:1px solid rgba(127,240,255,.45);border-width:0 1px;background:repeating-linear-gradient(90deg,rgba(127,240,255,.85) 0 1px,transparent 1px 9px) 0 0/100% 7px no-repeat}
.hh{position:absolute;left:0;right:0;top:calc(max(10px,env(safe-area-inset-top)) + 64px);bottom:232px;--w:0}#jxsh{bottom:236px}
.hh canvas{position:absolute;inset:0;width:100%;height:100%}.cr{position:absolute;pointer-events:none;transition:opacity .5s}.cr.hide{opacity:0}
.row{position:absolute;left:16px;right:16px;top:calc(max(10px,env(safe-area-inset-top)) + 26px);display:flex;justify-content:space-between;align-items:center;font-size:11px}.row b{font-size:26px;font-weight:600;letter-spacing:.06em;color:#fff;text-shadow:0 0 12px var(--jc)}
.lb{position:absolute;left:12px;top:calc(max(10px,env(safe-area-inset-top)) + 110px);display:grid;gap:9px;width:64px;font-size:8px}.lb i{display:block;height:4px;background:linear-gradient(90deg,var(--jc) var(--w),rgba(255,255,255,.15) 0);margin-top:3px;box-shadow:0 0 8px rgba(79,227,255,.5)}
.hx{position:absolute;left:12px;bottom:236px;width:92px;opacity:.8}.gb{position:absolute;right:12px;bottom:236px;width:86px;opacity:.8;animation:jxs 30s linear infinite}
.tl{position:absolute;left:10px;right:10px;bottom:86px;display:grid;grid-template-columns:repeat(5,1fr);gap:7px}
.tl button{height:62px;border-radius:14px;border:1px solid rgba(79,227,255,.45);background:linear-gradient(160deg,rgba(79,227,255,.16),rgba(4,24,40,.7));color:#cdf6ff;font:800 8px ui-monospace,monospace;letter-spacing:.1em;display:grid;gap:3px;place-items:center;box-shadow:inset 0 0 14px rgba(79,227,255,.12)}.tl button b{font-size:21px;font-weight:400}.tl button:active{background:rgba(79,227,255,.35)}
.sbar{position:absolute;left:12px;right:12px;top:calc(max(10px,env(safe-area-inset-top)) + 22px);height:54px;border-radius:27px;border:1px solid rgba(79,227,255,.4);border-top-color:#7ff0ff;background:rgba(3,14,26,.8);display:flex;align-items:center;justify-content:space-between;padding:0 14px;font-size:10px;box-shadow:0 0 20px rgba(79,227,255,.18)}
.sbar b{text-align:center;font-size:15px;letter-spacing:.2em;color:#fff;text-shadow:0 0 10px var(--jc)}.sbar small{display:block;font-size:7px;letter-spacing:.2em;color:#7fb0c4}.sbar button{background:none;border:0;color:#fff;font-size:20px}
.cap{position:absolute;left:18px;right:18px;bottom:192px;text-align:center;font:600 14px/1.35 Manrope,system-ui,sans-serif;letter-spacing:0;color:#cfefff;height:40px;overflow:hidden}
.chs{position:absolute;left:0;right:0;bottom:158px;display:flex;gap:8px;justify-content:center}.chs button,.pill button{border:1px solid rgba(79,227,255,.5);background:rgba(4,24,40,.8);color:#cdf6ff;border-radius:16px;padding:7px 13px;font:800 10px ui-monospace,monospace;letter-spacing:.1em}
.pill{position:absolute;left:34px;right:34px;bottom:90px;height:56px;border-radius:28px;border:1px solid rgba(79,227,255,.45);background:rgba(3,14,26,.88);display:flex;align-items:center;gap:8px;padding:0 10px 0 18px;font-size:13px;color:#fff}.pill span{flex:1}
.pill .dot{width:9px;height:9px;border-radius:50%;background:#ffb02e;box-shadow:0 0 10px #ffb02e}.pill button{width:40px;height:40px;border-radius:50%;padding:0;font-size:16px}.pill button.on{background:var(--jc);color:#001018}
.pill.live .dot{background:#4fff9a;box-shadow:0 0 12px #4fff9a}
.prof{position:absolute;inset:calc(max(10px,env(safe-area-inset-top)) + 24px) 16px 96px;overflow:auto;display:flex;flex-direction:column;gap:10px;align-items:center;scrollbar-width:none}
.prof .big{width:120px;height:120px;flex:none;margin:20px 0 10px}.prof h2{font-size:18px;color:#fff;letter-spacing:.2em}.pg{display:grid;grid-template-columns:1fr 1fr;gap:8px;width:100%}.pg div,.pk button{border:1px solid rgba(79,227,255,.35);background:rgba(4,24,40,.7);border-radius:14px;padding:12px;text-align:center}.pg b{display:block;font-size:20px;color:#fff;margin-bottom:2px}
.pk{display:grid;gap:8px;width:100%}.pk button{color:#cdf6ff;font:800 11px ui-monospace,monospace;letter-spacing:.14em}
#jxo{position:fixed;right:8px;top:calc(max(10px,env(safe-area-inset-top)) + 128px);width:84px;height:84px;z-index:9;display:none;touch-action:none}
#jxi{position:fixed;inset:0;z-index:101;background:#01060c;transition:background 1s;display:grid;place-items:center}#jxi .ib{width:min(62vw,270px);aspect-ratio:1}#jxi .ar{--o:.3}
#jxit{position:absolute;left:0;right:0;top:calc(50% + min(34vw,150px) + 30px);text-align:center;font:800 20px ui-monospace,monospace;letter-spacing:.5em;color:#fff;text-shadow:0 0 18px var(--jc);transition:opacity .6s}#jxit small{display:block;font-size:10px;letter-spacing:.3em;color:#7fb0c4;margin-top:8px}
#jxi.fly{background:transparent}#jxi.fly #jxit{opacity:0}
#jx3,#jxv{position:fixed;inset:0;z-index:28;display:none;background:radial-gradient(80% 55% at 50% 42%,rgba(20,90,160,.45),#02060f 72%),#02060f;color:#bdeeff;font:700 11px ui-monospace,monospace}#jx3.on,#jxv.on{display:block}
#jx3 .t3{position:absolute;top:calc(max(10px,env(safe-area-inset-top)) + 8px);left:0;right:0;text-align:center;font-size:17px;letter-spacing:.34em;color:#7ff0ff}#jx3 .t3 small{display:block;font-size:10px;letter-spacing:.2em;margin-top:2px}
#jx3h{position:absolute;left:0;right:0;top:calc(max(10px,env(safe-area-inset-top)) + 50px);bottom:110px;touch-action:none}#jx3h canvas{position:absolute;inset:0;width:100%;height:100%}
#jx3 .bt{position:absolute;left:14px;right:14px;bottom:max(18px,env(safe-area-inset-bottom));display:flex;justify-content:space-between;align-items:center;gap:8px}#jx3t{letter-spacing:.2em;color:#9fb0c8;font-size:10px}
.b3{padding:13px 12px;border-radius:26px;border:1px solid rgba(255,255,255,.3);background:linear-gradient(180deg,rgba(255,255,255,.14),rgba(255,255,255,.03));color:#fff;font:800 12px Manrope,system-ui,sans-serif;letter-spacing:.08em}
#jxv{overflow:auto;padding:calc(max(10px,env(safe-area-inset-top)) + 8px) 14px 30px;background:#03080f}#jxv>*{max-width:560px;margin:0 auto 10px;display:flex}#jxv .vh{justify-content:space-between;align-items:center;font-size:16px;letter-spacing:.2em;color:#7ff0ff}
#jxv video{width:100%;border-radius:14px;background:#000;max-height:34vh}#jxv .vg{gap:8px}#jxv .vg>*{flex:1;min-width:0}#jxv input,#jxv select,#jxv textarea{width:100%;height:44px;border-radius:12px;background:rgba(255,255,255,.08);border:1px solid rgba(79,227,255,.4);color:#fff;font:600 14px Manrope,system-ui,sans-serif;padding:0 10px}#jxv textarea{height:90px;padding:10px;resize:none}
#jxv button,#jxv .fb{height:46px;border-radius:14px;border:1px solid var(--jc);background:rgba(79,227,255,.14);color:#fff;font:800 12px ui-monospace,monospace;letter-spacing:.1em;display:grid;place-items:center}#jxv #vai{background:linear-gradient(135deg,#4fe3ff,#6a7bff);color:#001018;border:0}#jxv #vo{flex-direction:column;gap:8px}#jxv #vo a{color:#7ff0ff;text-align:center;padding:10px}`;
document.head.append(st);
/* ---------- real mesh renderer: the uploaded model as solid triangles, rigged shoulders / elbows / head / jaw ---------- */
const VS=`attribute vec3 p,n;attribute vec4 c;uniform float yaw,head,jaw,asp,sc;uniform vec3 uA,uB;varying vec3 vc,vn;varying float ve,vy;
void rx(inout vec3 q,inout vec3 m,vec3 o,float a){q-=o;float c=cos(a),s=sin(a);q=vec3(q.x,q.y*c+q.z*s,-q.y*s+q.z*c);q+=o;m=vec3(m.x,m.y*c+m.z*s,-m.y*s+m.z*c);}
void rz(inout vec3 q,inout vec3 m,vec3 o,float a){q-=o;float c=cos(a),s=sin(a);q=vec3(q.x*c-q.y*s,q.x*s+q.y*c,q.z);q+=o;m=vec3(m.x*c-m.y*s,m.x*s+m.y*c,m.z);}
void ry(inout vec3 q,inout vec3 m,vec3 o,float a){q-=o;float c=cos(a),s=sin(a);q=vec3(q.x*c+q.z*s,q.y,-q.x*s+q.z*c);q+=o;m=vec3(m.x*c+m.z*s,m.y,-m.x*s+m.z*c);}
void main(){vec3 q=p,m=n;q.y-=jaw*.032*smoothstep(1.785,1.805,p.y)*(1.-smoothstep(1.835,1.855,p.y))*smoothstep(.06,.12,p.z);
ry(q,m,vec3(0.,1.78,0.),head*smoothstep(1.76,1.84,p.y));
float sg=p.x<0.?-1.:1.;vec3 u=sg<0.?uA:uB;float wE=smoothstep(.17,.25,abs(p.x))*(1.-smoothstep(1.36,1.46,p.y)),wA=smoothstep(.22,.30,abs(p.x))*(1.-smoothstep(1.50,1.66,p.y));
rx(q,m,vec3(sg*.30,1.42,0.),u.z*wE);rx(q,m,vec3(sg*.30,1.56,0.),u.y*wA);rz(q,m,vec3(sg*.30,1.56,0.),sg*u.x*wA);
q.y-=1.64;ry(q,m,vec3(0.),yaw);vc=c.rgb;vn=normalize(m);ve=c.a;vy=q.y;gl_Position=vec4(q.x*sc/asp,q.y*sc,-q.z*.4,3.-q.z);}`;
const FS=`precision mediump float;uniform float holo,pulse,blink,tm;varying vec3 vc,vn;varying float ve,vy;
void main(){vec3 n=normalize(vn),col;float rim=pow(1.-clamp(n.z,0.,1.),2.5);
if(holo>1.5){float sc=.75+.25*sin(vy*110.-tm*2.),sw=exp(-pow((fract(tm*.22)*1.5-.25-(vy+.5))*8.,2.));col=vec3(.3,.8,1.)*(.5*sc+.8*sw);}
else if(holo>.5){float fr=pow(1.-abs(n.z),2.2),sc=.7+.3*sin(vy*120.-tm*2.),sw=exp(-pow((fract(tm*.22)*1.5-.25-(vy+.5))*8.,2.));
col=vec3(.05,.34,.78)*(.05+fr*.8)*sc+vec3(.3,.8,1.)*sw*.16*(.3+fr);if(ve>1.5)col+=vec3(.5,.95,1.)*blink*1.8;else if(ve>.5)col+=vec3(.5,.95,1.)*(1.1+pulse);}
else{vec3 l=normalize(vec3(-.5,.6,.8));float d=max(dot(n,l),0.),sp=pow(max(dot(reflect(-l,n),vec3(0.,0.,1.)),0.),24.);
col=vc*(.22+.8*d)+vec3(.9,.95,1.)*sp*.5+vec3(.15,.3,.45)*rim*.6+vec3(.05,.08,.12)*(n.y*.5+.5);
if(ve>1.5)col=vc*blink*1.4;else if(ve>.5)col=vc*(1.3+pulse*1.6);}
gl_FragColor=vec4(col,1.);}`;
let LB=null,nL=0,IB=null,EB=null,nE=0,gl,pr,U={},D,nI=0,RC=[0,1.64,.3],RR=.05,gcv=E('canvas');
const MCOL=[[.07,.07,.09,0],[.62,.04,.05,0],[.9,.65,.14,0],[.68,.7,.76,0],[.12,.25,.32,0],[.4,.95,1,1],[.85,.97,1,2]];
const u8=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0)),u16=s=>{const a=u8(s);return new Uint16Array(a.buffer,0,a.length>>1)};
function gInit(){try{const B=JXB,n=B.n,q=u16(B.P),mt=u8(B.M),ix=u16(B.I),ie=u16(B.E),il=u16(B.L),P=new Float32Array(n*3),C=new Float32Array(n*4),N=new Float32Array(n*3);
 for(let i=0;i<n*3;i++)P[i]=q[i]/65535*B.sc+B.lo[i%3];
 for(let i=0;i<n;i++){const m=MCOL[mt[i]];C[i*4]=m[0];C[i*4+1]=m[1];C[i*4+2]=m[2];C[i*4+3]=m[3]}
 for(let i=0;i<ix.length;i+=3){const a=ix[i]*3,b=ix[i+1]*3,c=ix[i+2]*3,ux=P[b]-P[a],uy=P[b+1]-P[a+1],uz=P[b+2]-P[a+2],vx=P[c]-P[a],vy=P[c+1]-P[a+1],vz=P[c+2]-P[a+2],nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;for(const o of[a,b,c]){N[o]+=nx;N[o+1]+=ny;N[o+2]+=nz}}
 for(let i=0;i<n*3;i+=3){const l=Math.hypot(N[i],N[i+1],N[i+2])||1;N[i]/=l;N[i+1]/=l;N[i+2]/=l}
 D={n,P,N,C};gl=gcv.getContext('webgl',{antialias:false,alpha:true,depth:true,powerPreference:'low-power'});if(!gl)return 0;
 const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))console.error('3D shader: '+gl.getShaderInfoLog(o));return o};
 pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pr);if(!gl.getProgramParameter(pr,gl.LINK_STATUS))console.error('3D link: '+gl.getProgramInfoLog(pr));gl.useProgram(pr);
 [['p',P,3],['n',N,3],['c',C,4]].forEach(([k,a,z])=>{const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,a,gl.STATIC_DRAW);const l=gl.getAttribLocation(pr,k);gl.enableVertexAttribArray(l);gl.vertexAttribPointer(l,z,gl.FLOAT,false,0,0)});
 const eb=a=>{const b=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,b);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,a,gl.STATIC_DRAW);return b};
 IB=eb(ix);nI=ix.length;EB=eb(ie);nE=ie.length;LB=eb(il);nL=il.length;
 'yaw head jaw asp sc tm uA uB holo pulse blink'.split(' ').forEach(k=>U[k]=gl.getUniformLocation(pr,k));
 let m=0,x=0,y=0,z=0;for(let i=0;i<n;i++)if(C[i*4+3]==1){x+=P[i*3];y+=P[i*3+1];z+=P[i*3+2];m++}
 if(m){RC=[x/m,y/m,z/m];RR=0;for(let i=0;i<n;i++)if(C[i*4+3]==1)RR=Math.max(RR,Math.hypot(P[i*3]-RC[0],P[i*3+1]-RC[1]))}return 1}catch(e){console.error('3D init failed: '+e.message);return 0}}
/* arm poses: [shoulder-out, shoulder-forward, elbow] per arm */
const POSE=['AUTO','WAVE','FLEX','OPEN','AIM'],PZ=[null,s=>[[.05,0,.1],[1.7,.2,.5+.55*Math.sin(s*6)]],s=>[[1.1,0,1.9],[1.1,0,1.9]],s=>[[1.45,0,0],[1.45,0,0]],s=>[[.12,1.35,.15],[.12,1.35,.15]]];
const cA=[0,0,0],cB=[0,0,0];let ydrag=0;
function anim(s,stt){let a,b;const m=pose&&PZ[pose](s);
 if(m){a=m[0];b=m[1]}
 else if(stt=='speaking'){a=[.08+.1*Math.sin(s*1.9),.12*Math.sin(s*1.3),.5+.35*Math.sin(s*2.7)];b=[.08+.1*Math.sin(s*1.7+1),.12*Math.sin(s*1.5+2),.45+.35*Math.sin(s*2.3+1)]}
 else if(stt=='listening'){a=[.06,.15,.35];b=[.06,.15,.35]}
 else if(/thinking|research|execut|view/.test(stt)){a=[.05,.1,.2];b=[.25,.5,1.5+.1*Math.sin(s*2)]}
 else{a=[.04+.02*Math.sin(s*.8),0,.12];b=[.04+.02*Math.sin(s*.8+1),0,.12]}
 for(let i=0;i<3;i++){cA[i]+=(a[i]-cA[i])*.12;cB[i]+=(b[i]-cB[i])*.12}
 return{yaw:Math.sin(s*.3)*.05+ydrag,head:Math.sin(s*.4)*.05+(stt=='listening'?.08:0),jaw:stt=='speaking'?Math.min(1.4,.2+L*2.2):0,pulse:.25+.2*Math.sin(s*2.2)+L*1.2,blink:1-.9*Math.pow(Math.max(0,Math.sin(s*1.3)),60)}}
function render(host,s,hol,A,cr){const r=host.getBoundingClientRect(),d=Math.min(devicePixelRatio||1,1.75),W=Math.round(r.width*d),H=Math.round(r.height*d);if(!W||!H)return;
 if(gcv.parentNode!=host)host.prepend(gcv);if(gcv.width!=W||gcv.height!=H){gcv.width=W;gcv.height=H}
 gl.viewport(0,0,W,H);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 if(hol){gl.disable(gl.DEPTH_TEST);gl.enable(gl.BLEND);gl.blendFunc(1,1)}else{gl.enable(gl.DEPTH_TEST);gl.disable(gl.BLEND)}
 const sc=Math.min(5.2,5.4*W/H)*(hol?1.3:1.1),f=(k,v)=>gl.uniform1f(U[k],v);f('yaw',A.yaw);f('head',A.head);f('jaw',A.jaw);f('asp',W/H);f('sc',sc);f('tm',s);f('holo',hol?1:0);f('pulse',A.pulse);f('blink',A.blink);
 gl.uniform3f(U.uA,0,0,0);gl.uniform3f(U.uB,0,0,0);
 if(hol){gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,EB);gl.drawElements(gl.TRIANGLES,nE,gl.UNSIGNED_SHORT,0);f('holo',2);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,LB);gl.drawElements(gl.LINES,nL,gl.UNSIGNED_SHORT,0)}
 else{gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,IB);gl.drawElements(gl.TRIANGLES,nI,gl.UNSIGNED_SHORT,0)}
 if(cr){const cy=Math.cos(A.yaw),sy=Math.sin(A.yaw),X=RC[0]*cy+RC[2]*sy,Z=-RC[0]*sy+RC[2]*cy,w=3-Z,px=(X*sc/(W/H)/w*.5+.5)*r.width,py=(.5-(RC[1]-1.64)*sc/w*.5)*r.height,z=RR*sc/w*r.height*1.6;
  cr.style.cssText=`left:${px-z/2}px;top:${py-z/2}px;width:${z}px;height:${z}px`;glow(cr,Math.min(1,.5+L*.8+.1*Math.sin(s*2.2)),1+L*.45)}}
/* ---------- audio level (AI voice or mic) ---------- */
function level(){let v=0;try{if(sp)v=ana?lv():.3+.25*Math.sin(Date.now()/110);else if(listening)v=mana?lvm():.25+.2*Math.sin(Date.now()/130)}catch(e){}L+=(v-L)*(v>L?.5:.12);return Math.min(1,L)}
/* ---------- pages ---------- */
const mk=(id,h)=>{const s=E('section','jxp',h);s.id=id;document.body.append(s);return s};
const deco=`<div class="rul"></div>${hex}${globe}`;
const TL=[['💬','CHAT',()=>go('chat')],['🎙','SPEAK',()=>go('speak')],['🎬','VIDEO',()=>openVid()],['🦾','SUIT 3D',()=>open3(true)],['👁','VISION',()=>{go('chat');$('bCam').click()}],['📊','DATA',()=>{go('chat');typeof setMode=='function'&&setMode('data')}],['🤖','AGENTS',()=>$('bAg').click()],['📝','NOTES',()=>$('sNotes').click()],['🧠','MEMORY',()=>$('sMem').click()],['⛅','WEATHER',()=>{go('chat');turn("What's the weather right now?")}]];
mk('jxh',`${deco}<div class="row"><span id="jxd"></span><span id="jxn"></span><b id="jxk"></b></div><div class="lb"><div>BATTERY<i id="jb1"></i></div><div>MEMORY<i id="jb2"></i></div><div>NETWORK<i id="jb3"></i></div></div><div class="hh" id="jxhh"><div class="cr hide" id="jxhr">${AR()}</div></div><div class="tl" id="jxtl"></div>`);
$('jxtl').append(...TL.map(([i,l,f])=>{const b=E('button','',`<b>${i}</b>${l}`);b.onclick=f;return b}));
mk('jxs',`${deco}<div class="sbar"><span id="jxb">--%<small id="jxr2">RAM --</small></span><b>JARVIS<small>AI COMPANION</small></b><span id="jxk2"></span><button id="jxg2">⚙</button></div><div class="hh" id="jxsh"><div class="cr" id="jxsr">${AR()}</div></div><div class="cap" id="jxsc"></div><div class="chs"><button id="jxsol">◆ SOLID 3D</button><button id="jxfl">⧉ FLOAT</button></div><div class="pill" id="jxpl"><i class="dot"></i><span id="jxss">Speak</span><button id="jxm">🎙</button><button id="jxpw" class="on">⏻</button><button id="jxcv">⌃</button></div>`);
mk('jxf',`<div class="prof"><div class="big">${AR()}</div><h2 id="jpn"></h2><div class="pg" id="jpg"></div><div class="pk" id="jpk"></div></div>`);
$('jxg2').onclick=()=>$('bSet').click();$('jxsol').onclick=()=>open3(true);$('jxfl').onclick=pip;
$('jxm').onclick=()=>{if(sp)stopSay();listen()};$('jxcv').onclick=()=>{const c=document.querySelector('#jxs .chs');c.style.display=c.style.display=='none'?'flex':'none'};
$('jxpw').onclick=function(){C.hf=!C.hf;this.classList.toggle('on',C.hf);if(!C.hf){stopSay();listening&&rec&&rec.stop&&rec.stop()}else if(!listening&&!busy)listen()};
$('jxsh').onclick=()=>{if(sp||busy){stopSay();listen()}};
[['SETTINGS','bSet'],['MEMORY','sMem'],['NOTES','sNotes'],['PERMISSIONS','sPerm'],['API & PROVIDER','sKey'],['SIGN OUT','sLock']].forEach(([l,id])=>{const b=E('button','',l);b.onclick=()=>$(id).click();$('jpk').append(b)});
const tray=E('div','',`<button data-p="home"><b>⌂</b>HOME</button><button data-p="prof"><b>☺</b>PROFILE</button><button class="mid" data-p="speak">${AR()}</button><button data-p="vid"><b>🎬</b>STUDIO</button><button data-p="chat"><b>💬</b>CHAT</button>`);tray.id='jxt';document.body.append(tray);
tray.onclick=e=>{const b=e.target.closest('button');if(b)b.dataset.p=='vid'?openVid():go(b.dataset.p)};
function go(p){const was=page;page=p;document.body.dataset.p=p;tray.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.p==p));
 if(was=='speak'&&p!='speak'){if(hfPrev!=null)C.hf=hfPrev;hfPrev=null;listening&&rec&&rec.stop&&rec.stop()}
 if(p=='speak'&&was!='speak'){hfPrev=C.hf;C.hf=true;$('jxpw').classList.add('on');ensurePv();setTimeout(()=>{page=='speak'&&!listening&&!busy&&!sp&&listen()},450)}
 if(p=='prof'){$('jpn').textContent=(C.name||'BOSS').toUpperCase();$('jpg').innerHTML=[[chats.length,'CHATS'],[mem.length,'MEMORIES'],[notes.length,'NOTES'],[C.voice,'VOICE'],[MODEL||'—','MODEL'],[C.aiName||'JARVIS','ASSISTANT']].map(([v,l])=>`<div><b>${String(v).slice(0,14)}</b>${l}</div>`).join('')}
 if(p!='chat'&&!raf)raf=requestAnimationFrame(loop)}
window.jxGo=go;window.jxLevel=()=>L;
/* ---------- 3D overlay (Iron Man solid / hologram) ---------- */
const v3=E('div','',`<div class="t3">IRON MAN<small id="jx3s">3D · GPU</small></div><div id="jx3h"></div><div class="bt"><button class="b3" id="jx3x">CLOSE</button><button class="b3" id="jx3p">ARMS: AUTO</button><span id="jx3t">IDLE</span><button class="b3" id="jx3m">HOLOGRAM</button></div>`);v3.id='jx3';document.body.append(v3);
function open3(s){if(s!=null)solid=s;$('jx3m').textContent=solid?'HOLOGRAM':'SOLID';v3.classList.add('on');if(!raf)raf=requestAnimationFrame(loop)}
$('jx3x').onclick=()=>v3.classList.remove('on');$('jx3m').onclick=()=>{solid=!solid;$('jx3m').textContent=solid?'HOLOGRAM':'SOLID'};
$('jx3p').onclick=()=>{pose=(pose+1)%POSE.length;$('jx3p').textContent='ARMS: '+POSE[pose]};
let dx=0;$('jx3h').onpointerdown=e=>{dx=e.clientX;e.target.setPointerCapture&&e.target.setPointerCapture(e.pointerId)};$('jx3h').onpointermove=e=>{if(e.buttons){ydrag+=(e.clientX-dx)*.01;dx=e.clientX}};
window.ironOpen=()=>open3(true);const bi=$('bIron');if(bi)bi.onclick=()=>open3(true);
/* ---------- main loop ---------- */
function loop(t){raf=0;const o3=v3.classList.contains('on'),h=o3?$('jx3h'):page=='home'?$('jxhh'):page=='speak'?$('jxsh'):null;
 if(!o3&&page=='chat'||document.hidden)return;raf=requestAnimationFrame(loop);if(t-last<(window.JX_NOGL?110:28))return;last=t;
 const stt=typeof cur=='function'?cur():'idle',s=t/1000;
 if(o3)$('jx3t').textContent=stt.toUpperCase();
 if(gl&&h){const A=anim(s,stt),cr=o3?null:page=='home'?$('jxhr'):$('jxsr');render(h,s,o3?!solid:true,A,cr)}
 if(page=='speak'&&!o3){const m=[...document.querySelectorAll('#msgs .m.j:not(.dots)')].pop(),T={listening:'Listening…',thinking:'Thinking…',researching:'Thinking…',executing:'Working…',viewing:'Looking…',speaking:'Speaking…'};
  $('jxss').textContent=T[stt]||'Speak';$('jxpl').classList.toggle('live',stt=='listening');
  $('jxsc').textContent=window.jxCaption?jxCaption(stt,m,T):window.jxI||(stt=='speaking'&&m?m.textContent.trim().slice(-130):stt=='idle'||!m?'I am ready for your commands, boss.':T[stt]||'')}}
/* ---------- clock / system stats ---------- */
let bat=null;try{navigator.getBattery&&navigator.getBattery().then(b=>bat=b)}catch(e){}
function stats(){const d=new Date(),hm=d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',hour12:false});$('jxk').textContent=hm;$('jxk2').textContent=hm;
 $('jxd').textContent=d.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'}).toUpperCase().replace(',','');$('jxn').textContent=`💬 ${chats.length}  🧠 ${mem.length}`;
 const b=bat?Math.round(bat.level*100):null,pm=performance.memory,ram=pm?Math.round(pm.usedJSHeapSize/pm.jsHeapSizeLimit*100):null,nt=navigator.connection&&navigator.connection.downlink;
 $('jb1').style.setProperty('--w',(b==null?60:b)+'%');$('jb2').style.setProperty('--w',(ram==null?50:ram)+'%');$('jb3').style.setProperty('--w',Math.min(100,(nt||5)*10)+'%');
 $('jxb').firstChild.textContent=(b==null?'--':b)+'%';$('jxr2').textContent='RAM '+(ram==null?'--':ram+'%')}
setInterval(stats,1000);stats();
/* ---------- floating orb + Picture-in-Picture (leave the app -> arc reactor keeps floating, moves with the AI voice) ---------- */
const oc=E('canvas');oc.id='jxo';oc.width=oc.height=256;document.body.append(oc);const og=oc.getContext('2d');
const GP=(()=>{const a=[],n=760,g=Math.PI*(3-Math.sqrt(5));for(let i=0;i<n;i++){const y=1-2*(i+.5)/n,r=Math.sqrt(1-y*y),t=g*i;a.push([Math.cos(t)*r,y,Math.sin(t)*r,i/n])}return a})();let gsm=0,gph=0;const FB=new Uint8Array(256);
function orb(s,k,stt){if(window.jxOrb)return window.jxOrb(og,oc.width,s,k);const g=og,S=oc.width,C=S/2,R=S*.33;g.clearRect(0,0,S,S);gph+=(/think|research|execut|view/.test(stt)?1.5:stt=='speaking'?1:stt=='listening'?.8:.4)*.016;gsm+=(k-gsm)*.22;const A=gsm;let an=sp?ana:listening?mana:null,has=0;try{if(an&&an.getByteFrequencyData){an.getByteFrequencyData(FB);has=1}}catch(e){}
 const gr=g.createRadialGradient(C,C,R*.2,C,C,R*1.5);gr.addColorStop(0,`rgba(40,140,255,${.16+A*.32})`);gr.addColorStop(1,'rgba(40,140,255,0)');g.fillStyle=gr;g.fillRect(0,0,S,S);
 const ca=Math.cos(gph),sa=Math.sin(gph),cy=Math.cos(.38),sy=Math.sin(.38),pts=[];
 for(const[x,y,z,u]of GP){const w=Math.sin(Math.asin(y)*5-s*(2+A*3))*.6+Math.sin(Math.atan2(z,x)*3+s*1.7)*.4,vv=has?FB[3+Math.floor((((Math.atan2(z,x)/TAU)+1)%1)*30)*2]/255:0,d=1+A*.24*w+.34*vv+.02*Math.sin(s*1.3+u*40),X=x*d,Y=y*d,Z=z*d,x1=X*ca+Z*sa,z1=-X*sa+Z*ca;pts.push([x1,Y*cy-z1*sy,Y*sy+z1*cy,u,vv])}
 pts.sort((a,b)=>a[2]-b[2]);g.globalCompositeOperation='lighter';
 for(const[x,y,z,u,vv]of pts){const f=(z+1.4)/2.4,r=(.75+1.6*f)*(S/200)*(1+A*.5+vv*.8);g.fillStyle=`hsla(${190+u*70+A*20+vv*30},100%,${58+f*22}%,${.22+.78*f})`;g.beginPath();g.arc(C+x*R,C+y*R,r,0,TAU);g.fill()}
 g.globalCompositeOperation='source-over'}
setInterval(()=>{const k=level(),show=((window.jxFloatOn?jxFloatOn():(sp||busy))||PIP)&&page!='speak'&&page!='chat';oc.style.display=show?'block':'none';if(show||PIP||page=='speak')orb(performance.now()/1000,Math.min(1,k*1.4),typeof cur=='function'?cur():'idle')},33);
let ox=0,oy=0;oc.onpointerdown=e=>{ox=e.clientX;oy=e.clientY;oc._m=0;oc.setPointerCapture(e.pointerId)};
oc.onpointermove=e=>{if(!e.buttons)return;const r=oc.getBoundingClientRect();if(Math.abs(e.clientX-ox)+Math.abs(e.clientY-oy)>4)oc._m=1;oc.style.right='auto';oc.style.bottom='auto';oc.style.left=Math.max(0,Math.min(innerWidth-r.width,r.left+e.clientX-ox))+'px';oc.style.top=Math.max(0,Math.min(innerHeight-r.height,r.top+e.clientY-oy))+'px';ox=e.clientX;oy=e.clientY};
oc.onpointerup=()=>{if(!oc._m)go('speak')};
function ensurePv(){if(pv)return pv;try{pv=E('video');pv.muted=true;pv.playsInline=true;pv.srcObject=oc.captureStream(30);pv.style.cssText='position:fixed;left:-9px;top:0;width:8px;height:8px';document.body.append(pv);pv.play().catch(()=>{})}catch(e){pv=null}return pv}
async function pip(){try{if(document.pictureInPictureElement){await document.exitPictureInPicture();PIP=0;return}const v=ensurePv();await v.play();await v.requestPictureInPicture();PIP=1;v.onleavepictureinpicture=()=>PIP=0}catch(e){pp('Floating window needs Chrome with Picture-in-Picture allowed')}}
try{navigator.mediaSession.setActionHandler('enterpictureinpicture',()=>{pip()})}catch(e){}
document.addEventListener('visibilitychange',()=>{if(document.hidden&&page=='speak'&&pv&&!PIP)pv.requestPictureInPicture().then(()=>PIP=1).catch(()=>{});if(!document.hidden&&!raf&&page!='chat')raf=requestAnimationFrame(loop)});
/* ---------- offline speech-to-text: on-device Chrome recognizer, else Whisper (WASM, cached for offline use) ---------- */
const setLive=v=>$('bMic')&&$('bMic').classList.toggle('live',!!v);let WP=null;
async function whisper(blob){if(!WP){pp('Loading offline speech model (internet needed once)…');const{pipeline,env}=await import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.0.2');env.allowLocalModels=false;WP=await pipeline('automatic-speech-recognition',/^en/i.test(C.lang||'en')?'Xenova/whisper-tiny.en':'Xenova/whisper-tiny')}
 ac=ac||new(window.AudioContext||webkitAudioContext)();const a=await ac.decodeAudioData(await blob.arrayBuffer()),oc2=new OfflineAudioContext(1,Math.ceil(a.duration*16000),16000),s=oc2.createBufferSource();s.buffer=a;s.connect(oc2.destination);s.start();
 const r=await oc2.startRendering(),o=await WP(r.getChannelData(0));return(o.text||'').replace(/\[[^\]]*\]|\([^)]*\)/g,'').trim()}
async function recWhisper(){let ms;try{ms=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,channelCount:1}})}catch(e){return pErr('Microphone',e)}
 micAnalyser(ms);const mr=new MediaRecorder(ms),ch=[];let spoke=0,quiet=0;const t0=Date.now();
 rec={stop:()=>{mr.state!='inactive'&&mr.stop()}};listening=true;setLive(1);
 const iv=setInterval(()=>{const v=lvm();if(v>.06){spoke=1;quiet=0}else if(spoke&&++quiet>7)rec.stop();if(Date.now()-t0>25000)rec.stop()},100);
 mr.ondataavailable=e=>e.data.size&&ch.push(e.data);
 mr.onstop=async()=>{clearInterval(iv);ms.getTracks().forEach(t=>t.stop());micOff();listening=false;setLive(0);if(!spoke)return after();
  srv='thinking';try{const t=await whisper(new Blob(ch));srv='idle';t?turn(t):after()}catch(e){srv='idle';add('n','Offline speech failed: '+e.message+'\nFirst use needs internet to download the speech model.')}};
 mr.start()}
function recLocal(R){const r=new R;let fin='',fb=0;r.lang=C.lang||'en-US';r.processLocally=true;r.interimResults=true;r.continuous=false;rec=r;
 r.onstart=()=>{listening=true;setLive(1)};
 r.onresult=e=>{let s='';for(const x of e.results){s+=x[0].transcript;if(x.isFinal)fin=s}window.jxI=s;$('q').value=s};
 r.onerror=e=>{if(e.error=='language-not-supported'||e.error=='service-not-allowed'){noLocal=1;fb=1}else if(e.error!='no-speech'&&e.error!='aborted')pp('Speech: '+e.error)};
 r.onend=()=>{listening=false;setLive(0);window.jxI='';const t=(fin||$('q').value).trim();$('q').value='';if(fb)return recWhisper();t?turn(t):after()};
 try{r.start()}catch(e){recWhisper()}}
window.listen2=async function(){stopSay();if(listening&&rec&&rec.stop){rec.stop();return}
 if(!isSecureContext||!navigator.mediaDevices)return pErr('Microphone',{name:'Insecure'});
 const R=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(R&&!noLocal&&'processLocally'in R.prototype){try{const o={langs:[C.lang||'en-US'],processLocally:true};if(R.available){let a=await R.available(o);if(a=='downloadable'||a=='downloading'){pp('Downloading offline speech pack…');R.install&&await R.install(o);a=await R.available(o)}if(a!='available')noLocal=1}}catch(e){noLocal=1}
  if(!noLocal)return recLocal(R)}
 return recWhisper()};
/* ---------- Video Studio: trim · filter · caption · Gemini voiceover auto-added · export ---------- */
const vo=E('div','',`<div class="vh"><b>VIDEO STUDIO</b><button id="vx" style="width:44px">✕</button></div><video id="vp" playsinline controls></video><label class="fb">Choose video<input id="vf" type="file" accept="video/*" hidden></label>
<div class="vg"><input id="v0" type="range" min="0" max="1" step=".1" value="0"><input id="v1" type="range" min="0" max="1" step=".1" value="1"></div>
<div class="vg"><select id="vfl"><option value="none">Original</option><option value="contrast(1.2) saturate(1.3)">Vivid</option><option value="sepia(.5) contrast(1.1)">Warm film</option><option value="grayscale(1) contrast(1.2)">Noir</option><option value="hue-rotate(160deg) saturate(1.5) brightness(1.05)">HUD blue</option></select><input id="vc" placeholder="Caption (optional)"></div>
<textarea id="vt" placeholder="Voiceover script. Leave empty and JARVIS writes it from your video."></textarea>
<div class="vg"><button id="vai">✨ AUTO EDIT + GEMINI VOICE</button></div><div class="vg" style="font-size:11px;color:#9fb0c8" id="vst">Trim = left start, right end. Voice is added automatically.</div><div id="vo"></div>`);vo.id='jxv';document.body.append(vo);
let VB=null,vurl=null;const vs=m=>$('vst').textContent=m,seek=(v,t)=>new Promise(r=>{if(Math.abs(v.currentTime-t)<.05)return r();v.onseeked=()=>r();v.currentTime=t});
function openVid(){vo.classList.add('on')}$('vx').onclick=()=>{$('vp').pause();vo.classList.remove('on')};
$('vf').onchange=e=>{const f=e.target.files[0];if(!f)return;vurl&&URL.revokeObjectURL(vurl);const v=$('vp');v.src=vurl=URL.createObjectURL(f);v.onloadedmetadata=()=>{$('v0').max=$('v1').max=v.duration;$('v0').value=0;$('v1').value=v.duration;vs('Loaded '+v.duration.toFixed(1)+' s')}};
async function script(T0,T1){const v=$('vp');await seek(v,(T0+T1)/2);const f=grab(v);return txt(await gen([{role:'user',parts:[...(f?[{inline_data:{mime_type:'image/jpeg',data:f}}]:[]),{text:`Write a short, punchy voiceover narration for this ${Math.round(T1-T0)}-second video clip, about ${Math.round((T1-T0)*2.3)} words, in the language and tone of a confident AI assistant. Plain sentences only: no markdown, no stage directions.`}]}]))}
async function exportV(T0,T1){const v=$('vp'),a=ac=ac||new(window.AudioContext||webkitAudioContext)();await a.resume();if(VB)T1=Math.min(v.duration,Math.max(T1,T0+VB.duration+.4));
 const w=Math.min(v.videoWidth,1280),h=Math.round(w*v.videoHeight/v.videoWidth),c=E('canvas');c.width=w;c.height=h;const g=c.getContext('2d'),d=a.createMediaStreamDestination();
 if(!v._s){v._s=a.createMediaElementSource(v);v._g=a.createGain();v._s.connect(v._g);v._g.connect(a.destination)}
 v._g.gain.value=VB?.25:1;v._g.disconnect();v._g.connect(d);let bs=null;if(VB){bs=a.createBufferSource();bs.buffer=VB;bs.connect(d)}
 const mt=MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')?'video/webm;codecs=vp8,opus':'video/webm',mr=new MediaRecorder(new MediaStream([...c.captureStream(30).getVideoTracks(),...d.stream.getAudioTracks()]),{mimeType:mt}),ch=[],done=new Promise(r=>mr.onstop=r);
 mr.ondataavailable=e=>e.data.size&&ch.push(e.data);v.pause();v.controls=false;await seek(v,T0);const fl=$('vfl').value,cap=$('vc').value;
 mr.start();bs&&bs.start();await v.play();vs('Rendering… keep this screen open');
 await new Promise(res=>{const f=()=>{if(v.currentTime>=T1||v.ended)return res();g.filter=fl;g.drawImage(v,0,0,w,h);g.filter='none';if(cap){g.font=`800 ${h*.05}px sans-serif`;g.textAlign='center';g.fillStyle='#fff';g.strokeStyle='#000';g.lineWidth=h*.008;g.strokeText(cap,w/2,h*.9);g.fillText(cap,w/2,h*.9)}requestAnimationFrame(f)};f()});
 v.pause();try{bs&&bs.stop()}catch(e){}mr.stop();await done;v._g.disconnect();v._g.connect(a.destination);v.controls=true;
 const u=URL.createObjectURL(new Blob(ch,{type:'video/webm'}));$('vo').innerHTML=`<video src="${u}" controls playsinline></video><a href="${u}" download="jarvis-edit.webm">⬇ Save video</a>`;vs('Done ✓ Gemini voice added')}
$('vai').onclick=async()=>{const v=$('vp');if(!v.src)return pp('Choose a video first');if(!K.g)return pp('Gemini voice needs your Gemini key (Settings > API)');
 let T0=+$('v0').value,T1=+$('v1').value;if(T1<=T0+.3)T1=v.duration;
 try{let t=$('vt').value.trim();if(!t){vs('JARVIS is writing the script…');t=(await script(T0,T1)).trim();$('vt').value=t}
  vs('Generating Gemini voice…');VB=await tts(cl(t),gid);if(!VB)throw Error('Voice failed');await exportV(T0,T1)}catch(e){vs('Error: '+e.message)}};
/* ---------- startup: arc reactor boots (beeps), then flies into Iron Man's chest ---------- */
if(!window.JX_NOGL){const ok=gInit();if(!ok)pp('3D needs WebGL on this phone')}
go('home');
function intro(){const o=E('div','',`<div class="ib">${AR()}</div><div id="jxit">J.A.R.V.I.S<small>INITIALIZING</small></div>`);o.id='jxi';document.body.append(o);
 const big=o.firstChild,ar=big.firstChild,pu=()=>{glow(big,1,1.4);setTimeout(()=>glow(big,.4,1),140)},
 bp=(f,d=.12,v=.06)=>{try{ac=ac||new(window.AudioContext||webkitAudioContext)();const s=ac.createOscillator(),g=ac.createGain();s.frequency.value=f;g.gain.setValueAtTime(v,ac.currentTime);g.gain.exponentialRampToValueAtTime(.0001,ac.currentTime+d);s.connect(g);g.connect(ac.destination);s.start();s.stop(ac.currentTime+d)}catch(e){}};
 [350,800,1250].forEach((t,i)=>setTimeout(()=>{bp(500+i*180);pu()},t));
 setTimeout(()=>{bp(880,.5,.08);pu();$('jxit').firstChild.nextSibling.textContent='SYSTEM ONLINE'},1800);
 setTimeout(()=>{const h=$('jxhr');h.classList.remove('hide');const t=h.getBoundingClientRect(),b=big.getBoundingClientRect();h.classList.add('hide');
  big.style.transition='transform 1s cubic-bezier(.6,0,.2,1)';big.style.transform=`translate(${t.left+t.width/2-b.left-b.width/2}px,${t.top+t.height/2-b.top-b.height/2}px) scale(${t.width/b.width})`;o.classList.add('fly');bp(660,.3,.05)},2800);
 setTimeout(()=>{$('jxhr').classList.remove('hide');o.remove()},3850);setTimeout(()=>{$('jxhr').classList.remove('hide');o.isConnected&&o.remove()},7000)}
if(!window.JX_NEWINTRO)try{intro()}catch(e){$('jxhr').classList.remove('hide')}
})();
