/* JARVIS v7 · real 3D hologram: front-only lines, rigged arms/head/torso, blink, gestures. Auto-falls back to the image figure on slow phones. */
(()=>{
const $=i=>document.getElementById(i),LS=(k,v)=>{try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){return null}};
const VS=`attribute vec3 p;uniform vec3 hd,uA,uB,c0;uniform vec4 tb;uniform float yaw,sc,ps;varying float vy,vz;
void rx(inout vec3 q,vec3 o,float a){q-=o;float c=cos(a),s=sin(a);q=vec3(q.x,q.y*c+q.z*s,-q.y*s+q.z*c);q+=o;}
void rz(inout vec3 q,vec3 o,float a){q-=o;float c=cos(a),s=sin(a);q=vec3(q.x*c-q.y*s,q.x*s+q.y*c,q.z);q+=o;}
void ry(inout vec3 q,vec3 o,float a){q-=o;float c=cos(a),s=sin(a);q=vec3(q.x*c+q.z*s,q.y,-q.x*s+q.z*c);q+=o;}
void main(){vec3 q=p;
 q.y-=tb.x*.03*smoothstep(1.75,1.77,p.y)*(1.-smoothstep(1.83,1.85,p.y))*smoothstep(.05,.11,p.z)*(1.-smoothstep(.10,.16,abs(p.x)));
 float sg=p.x<0.?-1.:1.;vec3 u=sg<0.?uA:uB;float wA=smoothstep(.19,.27,abs(p.x))*(1.-smoothstep(1.50,1.63,p.y)),wE=wA*(1.-smoothstep(1.34,1.46,p.y));
 rx(q,vec3(sg*.37,1.41,0.),u.z*wE);rx(q,vec3(sg*.30,1.56,0.),u.y*wA);rz(q,vec3(sg*.30,1.56,0.),sg*u.x*wA);
 float wH=smoothstep(1.73,1.80,p.y);vec3 nk=vec3(0.,1.76,.02);ry(q,nk,hd.x*wH);rx(q,nk,hd.y*wH);rz(q,nk,hd.z*wH);
 float wT=smoothstep(1.12,1.55,p.y);vec3 wa=vec3(0.,1.15,0.);rz(q,wa,tb.y*wT);rx(q,wa,tb.z*wT);q.y+=(p.y-1.45)*tb.w*.012*wT;q.z+=tb.w*.012*wT;
 ry(q,vec3(0.,1.5,0.),yaw);
 vy=(q.y-c0.y)/sc;vz=clamp(.5+(q.z-c0.z)*1.3,0.,1.);gl_Position=vec4((q.x-c0.x)/sc,vy,-(q.z-c0.z)/.9,1.);gl_PointSize=ps;}`;
const FS=`precision mediump float;uniform vec4 col;uniform float mode,scan;varying float vy,vz;
void main(){if(mode>.5){gl_FragColor=vec4(col.rgb*col.a,col.a);return;}
 vec3 c=mix(vec3(.10,.38,.68),vec3(.42,.80,.97),smoothstep(-.6,.6,vy));float sw=exp(-pow((vy-scan)*8.,2.));
 gl_FragColor=vec4(c*(1.+sw*1.5),col.a*(.62+.38*vz)+sw*.45);}`;
let gl,U={},ready=0,failed=0,nI=0,nE=0,nL=0,nD=0,gc=document.createElement('canvas'),cw=0,lastHost=null,wave=0,SX=null;
const RC=[0,1.55,.28],C0=[0,1.55,.1],S=.6;gc.style.cssText='position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none';
const u8=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0)),u16=s=>{const a=u8(s);return new Uint16Array(a.buffer,0,a.length>>1)};
function init(){try{const B=JXB,n=B.n,q=u16(B.P),mt=u8(B.M),I=u16(B.I),E=u16(B.E),L=u16(B.L),P=new Float32Array(n*3);for(let i=0;i<n*3;i++)P[i]=q[i]/65535*B.sc+B.lo[i%3];
 gl=gc.getContext('webgl',{antialias:false,alpha:true,depth:true,powerPreference:'low-power'});if(!gl)return 0;
 const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,35713))throw Error(gl.getShaderInfoLog(o));return o};
 const pr=gl.createProgram();gl.attachShader(pr,sh(35633,VS));gl.attachShader(pr,sh(35632,FS));gl.linkProgram(pr);if(!gl.getProgramParameter(pr,35714))throw Error(gl.getProgramInfoLog(pr));gl.useProgram(pr);
 const pb=gl.createBuffer();gl.bindBuffer(34962,pb);gl.bufferData(34962,P,35044);const al=gl.getAttribLocation(pr,'p');gl.enableVertexAttribArray(al);gl.vertexAttribPointer(al,3,5126,false,0,0);
 const eb=a=>{const b=gl.createBuffer();gl.bindBuffer(34963,b);gl.bufferData(34963,a,35044);return b};
 const eyes=[];for(let i=0;i<E.length;i+=3)if(mt[E[i]]==6)eyes.push(E[i],E[i+1],E[i+2]);const dots=[];for(let i=0;i<n;i+=41)if(P[i*3+2]>.03&&P[i*3+1]>1.2)dots.push(i);
 U.IB=eb(I);nI=I.length;U.EB=eb(new Uint16Array(eyes));nE=eyes.length;U.LB=eb(L);nL=L.length;U.DB=eb(new Uint16Array(dots));nD=dots.length;
 'hd uA uB c0 tb yaw sc ps col mode scan'.split(' ').forEach(k=>U[k]=gl.getUniformLocation(pr,k));gl.uniform3fv(U.c0,C0);gl.uniform1f(U.sc,S);return 1}catch(e){console.error('3D init: '+e.message);return 0}}
/* ---------- animation ---------- */
const RG={hd:[0,0,0],tb:[0,0,0,0],a:[0,0,0],b:[0,0,0],yaw:0},sm=(k,dt)=>1-Math.exp(-dt*k);let gNext=6,gK=null,gT=0,nb=2,bT=-1,bN=0;
const GEST=[()=>({a:[.9,.1,.5],b:[.9,.1,.5],hd:[0,-.04,0]}),()=>({hd:[Math.random()<.5?.5:-.5,.04,0]}),()=>({a:[.55,.35,1.5],b:[.55,.35,1.5]}),()=>({b:[.25,1.15,.35],hd:[-.12,0,.05]}),()=>({a:[.3,0,.6],b:[1.4,.1,.3]})];
function rig(t,dt,st,L){const s=t,br=Math.sin(s*1.7);let a=[.05+.03*Math.sin(s*.8),.04*Math.sin(s*.6),.14+.05*Math.sin(s*1.1)],b=[.05+.03*Math.sin(s*.8+1),.04*Math.sin(s*.6+2),.14+.05*Math.sin(s*1.1+1)],hd=[Math.sin(s*.37)*.16+Math.sin(s*.91)*.04,Math.sin(s*.29)*.04,0],tb=[0,Math.sin(s*.5)*.012,0,br],yaw=Math.sin(s*.33)*.1,jaw=0;
 if(st=='listening'){a=[.22,.12,.4];b=[.22,.12,.4];hd=[Math.sin(s*.8)*.06,.04,.08*Math.sin(s*1.2)];tb[2]=.05;yaw=.04}
 else if(/think|research|execut|view/.test(st)){hd=[-.14,.1,.07];b=[.3,.95+.05*Math.sin(s*2),1.55];a=[.06,0,.2];tb[2]=.03}
 else if(st=='speaking'){const k=.35+L*1.4;a=[.14+.16*k*Math.sin(s*3.1),.22*k*Math.sin(s*2.3),.45+.35*Math.sin(s*2.7)*k];b=[.14+.16*k*Math.sin(s*2.7+1.6),.22*k*Math.sin(s*2.1+1),.45+.35*Math.sin(s*2.3+1)*k];hd=[Math.sin(s*1.3)*.1,.05*Math.sin(s*3)*(.5+L),.03*Math.sin(s*1.7)];tb[1]=.02*Math.sin(s*1.9);tb[2]=.015+.02*L;jaw=Math.min(1,.2+L*2.2)}
 else{if(t>gNext&&!gK){gK=GEST[Math.floor(Math.random()*GEST.length)]();gT=t}if(gK){const p=(t-gT)/2.2,g=p>=1?0:Math.sin(Math.PI*Math.min(1,p));if(p>=1){gK=null;gNext=t+8+Math.random()*6}else{if(gK.a)for(let i=0;i<3;i++)a[i]+=(gK.a[i]-a[i])*g;if(gK.b)for(let i=0;i<3;i++)b[i]+=(gK.b[i]-b[i])*g;if(gK.hd)for(let i=0;i<3;i++)hd[i]+=gK.hd[i]*g}}}
 if(performance.now()<wave){b=[1.75,.15,.55+.5*Math.sin(s*9)];hd=[-.08,0,.06]}
 if(window.JX9F){const f=window.JX9F;if(f.a)a=f.a;if(f.b)b=f.b;if(f.hd)hd=f.hd;if(f.jaw!=null)jaw=f.jaw;if(f.yaw!=null)yaw=f.yaw}
 const k=sm(7,dt);for(let i=0;i<3;i++){RG.a[i]+=(a[i]-RG.a[i])*k;RG.b[i]+=(b[i]-RG.b[i])*k;RG.hd[i]+=(hd[i]-RG.hd[i])*k}RG.tb[0]+=(jaw-RG.tb[0])*sm(14,dt);for(let i=1;i<4;i++)RG.tb[i]+=(tb[i]-RG.tb[i])*k;RG.yaw+=(yaw-RG.yaw)*sm(3,dt)}
/* ---------- frame ---------- */
let last=0,prev=0,ivs=[],slowN=0,t3d0=0;const host=()=>{const p=document.body.dataset.p;return p=='home'?$('jxhh'):p=='speak'?$('jxsh'):null};
function frame(t){requestAnimationFrame(frame);if(!ready||failed)return;const h=host();if(!h||document.hidden){prev=0;return}const fig=h.querySelector('.fig');if(!fig||!fig.offsetParent)return;const lite=document.body.classList.contains('lite');if(t-last<(lite?42:33))return;const dt=Math.min(.1,(t-last)/1000);last=t;
 if(!t3d0)t3d0=t;if(prev){ivs.push(t-prev);if(ivs.length>90)ivs.shift();if(ivs.length==90&&t-t3d0>7000&&LS('jx3dF')!='1'){const m=ivs.reduce((x,y)=>x+y,0)/90;if(m>90){if(++slowN>2)return fallback('3D paused so the app stays smooth. Tap the 3D button to switch it back on.')}else slowN=0}}prev=t;
 if(lastHost!==fig){lastHost=fig;fig.append(gc);fig.classList.add('g3');cw=0}const d=Math.min(devicePixelRatio||1,lite?1:1.25),px=Math.round(fig.clientWidth*d);if(px&&px!=cw){cw=px;gc.width=gc.height=px;gl.viewport(0,0,px,px)}
 const s=t/1000,stt=typeof cur=='function'?cur():'idle',L=window.jxLevel?jxLevel():0;rig(s,dt,stt,L);
 let bl=0;if(s>nb&&bT<0){bT=s;bN=Math.random()<.25?1:0}if(bT>=0){const p=(s-bT)/.15;if(p>=1){if(bN){bN=0;bT=s+.05}else{bT=-1;nb=s+2.2+Math.random()*3}}else if(p>=0)bl=Math.sin(Math.PI*p)}
 const pulse=.85+.15*Math.sin(s*2.2)+(stt=='listening'?.2:0);
 gl.clearColor(0,0,0,0);gl.clear(16640);gl.enable(2929);gl.depthFunc(515);gl.disable(3042);
 gl.uniform3f(U.hd,RG.hd[0],RG.hd[1],RG.hd[2]);gl.uniform4f(U.tb,RG.tb[0],RG.tb[1],RG.tb[2],RG.tb[3]);gl.uniform3f(U.uA,RG.a[0],RG.a[1],RG.a[2]);gl.uniform3f(U.uB,RG.b[0],RG.b[1],RG.b[2]);gl.uniform1f(U.yaw,RG.yaw);gl.uniform1f(U.scan,((s*.2)%1.7)-.6);gl.uniform1f(U.ps,2);
 gl.uniform1f(U.mode,0);gl.colorMask(false,false,false,false);gl.enable(32823);gl.polygonOffset(1.5,3);gl.bindBuffer(34963,U.IB);gl.drawElements(4,nI,5123,0);gl.disable(32823);gl.colorMask(true,true,true,true);
 gl.enable(3042);gl.blendFunc(770,1);gl.uniform4f(U.col,1,1,1,1);gl.bindBuffer(34963,U.LB);gl.drawElements(1,nL,5123,0);
 gl.uniform1f(U.mode,1);gl.bindBuffer(34963,U.DB);gl.uniform4f(U.col,.55,.85,1,.5);gl.drawElements(0,nD,5123,0);
 gl.bindBuffer(34963,U.EB);gl.uniform4f(U.col,.75,.97,1,Math.max(0,(1-bl)*pulse));gl.drawElements(4,nE,5123,0);
 const cr=fig.querySelector('.cr');if(cr){const y=RG.yaw,cy=Math.cos(y),sy=Math.sin(y);let x0=RC[0]-0,z0=RC[2];const X=x0*cy+z0*sy,Z=-x0*sy+z0*cy;let Y=RC[1]+(RC[1]-1.45)*RG.tb[3]*.012;cr.style.left=((X-C0[0])/S*.5+.5)*100+'%';cr.style.top=(.5-(Y-C0[1])/S*.5)*100+'%'}}
function fallback(msg){failed=1;if(lastHost){lastHost.classList.remove('g3')}gc.remove();document.querySelectorAll('.fig').forEach(f=>f.classList.remove('g3'));if(msg&&window.jx7note)jx7note(msg);LS('jx3d','0');syncT()}
const css=document.createElement('style');css.textContent='.fig.g3>img.fb,.fig.g3>img.fj,.fig.g3>img.fe{display:none}.fig .cr{z-index:2}';document.head.append(css);
window.jxWave=()=>{wave=performance.now()+2600};
let loaded=0;function load(){if(LS('jx3d')!='1'||loaded)return;loaded=1;const s=document.createElement('script');s.src='body.js?v=7';s.onload=()=>{if(init()){ready=1;requestAnimationFrame(frame)}else fallback()};s.onerror=()=>fallback();document.head.append(s)}
/* 3D option button + profile switch */
const lowEnd=(navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=6);
const on3=()=>LS('jx3d')=='1'&&!failed;
function syncT(){document.querySelectorAll('.t3d').forEach(b=>b.classList.toggle('on',on3()));const p=$('jx3p9');p&&(p.textContent='REAL 3D MODEL: '+(on3()?'ON':'OFF'))}
function set3D(on){LS('jx3d',on?'1':'0');LS('jx3dF',on?'1':'0');if(on){failed=0;lastHost=null;ivs=[];t3d0=0;slowN=0;loaded?0:load();window.jx7note&&jx7note('3D hologram on')}else{fallback();window.jx7note&&jx7note('Normal figure')}syncT()}
window.jx3dSet=set3D;
const tst=document.createElement('style');tst.textContent='.t3d{position:absolute;right:10px;top:6px;z-index:4;display:flex;gap:6px;align-items:center;padding:7px 12px;border-radius:14px;border:1px solid rgba(79,227,255,.45);background:rgba(4,20,34,.85);color:#bfe9f5;font:800 10px ui-monospace,monospace;letter-spacing:.12em}.t3d.on{background:#4fe3ff;color:#001018}.t3d svg{width:14px;height:14px}';document.head.append(tst);
for(const id of['jxhh','jxsh']){const h=$(id);if(!h)continue;const b=document.createElement('button');b.className='t3d';b.innerHTML=(window.JXI?JXI('cube',14):'')+'<span>3D</span>';b.onclick=()=>set3D(!on3());h.append(b)}
const pk=$('jpk');if(pk){const b=document.createElement('button');b.id='jx3p9';b.onclick=()=>set3D(!on3());pk.prepend(b)}
if(LS('jx3d')==null||LS('jx3d')=='auto')LS('jx3d',lowEnd?'0':'1');syncT();setTimeout(()=>{load();syncT()},3300);
})();
